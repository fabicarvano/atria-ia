# /atria.ia.br/app/contatos.py
from fastapi import APIRouter, Depends, HTTPException
from auth import get_current_user
from database import get_conn
from pydantic import BaseModel, validator
from typing import Optional

router = APIRouter(dependencies=[Depends(get_current_user)])

# ---------- MODELOS ----------
class ContatoCreate(BaseModel):
    nome: str
    cargo: str
    nivel_hierarquico_id: int
    email: str
    empresa_id: int
    telefone: Optional[str] = None
    telefone2: Optional[str] = None
    linkedin: Optional[str] = None
    contato_whatsapp: Optional[bool] = False
    tags: Optional[str] = None
    observacoes: Optional[str] = None
    reporta_a: Optional[int] = None
    departamento_id: Optional[int] = None

# ---------- MODELO DE ATUALIZAÇÃO ----------
class ContatoUpdate(BaseModel):
    nome: Optional[str] = None
    cargo: Optional[str] = None
    nivel_hierarquico_id: Optional[int] = None
    email: Optional[str] = None
    empresa_id: Optional[int] = None
    telefone: Optional[str] = None
    telefone2: Optional[str] = None
    linkedin: Optional[str] = None
    contato_whatsapp: Optional[bool] = None
    tags: Optional[str] = None
    observacoes: Optional[str] = None
    reporta_a: Optional[int] = None
    departamento_id: Optional[int] = None


    @validator('email')
    def validar_email(cls, v):
        if '@' not in v:
            raise ValueError("Email inválido")
        return v

# ---------- LISTAR COM PAGINAÇÃO ----------
@router.get("/")
def listar_contatos(
    page: int = 1,
    limit: int = 30,
    current_user: dict = Depends(get_current_user)
):
    """
    Lista todos os contatos com paginação.
    - **page**: Página atual (default=1)
    - **limit**: Quantidade por página (default=30)
    """
    try:
        offset = (page - 1) * limit
        conn = get_conn()
        cur = conn.cursor()

        # Contar total
        cur.execute("SELECT COUNT(*) FROM contatos")
        total = cur.fetchone()["count"]


        # Buscar dados paginados
        cur.execute("""
            SELECT id, nome, cargo, nivel_hierarquico_id, email, empresa_id,
                   telefone, telefone2, linkedin, contato_whatsapp, tags, observacoes,
                   reporta_a, departamento_id, created_at, updated_at, atualizado_em
            FROM contatos
            ORDER BY id ASC
            LIMIT %s OFFSET %s
        """, (limit, offset))
        rows = cur.fetchall()
        conn.close()

        return {
            "total": total,
            "page": page,
            "limit": limit,
            "pages": (total + limit - 1) // limit,
            "dados": [dict(r) for r in rows]
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro ao listar contatos: {str(e)}")

# ---------- CRIAR ----------
@router.post("/")
def criar_contato(
    contato: ContatoCreate,
    current_user: dict = Depends(get_current_user)
):
    """
    Cria um novo contato.
    """
    try:
        conn = get_conn()
        cur = conn.cursor()

        # Verificar se email já existe
        cur.execute("SELECT id FROM contatos WHERE email = %s", (contato.email,))
        existente = cur.fetchone()
        if existente:
            conn.close()
            raise HTTPException(status_code=400, detail="Email já cadastrado")

        cur.execute("""
            INSERT INTO contatos 
            (nome, cargo, nivel_hierarquico_id, email, empresa_id, telefone, telefone2,
             linkedin, contato_whatsapp, tags, observacoes, reporta_a, departamento_id)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            RETURNING id
        """, (
            contato.nome, contato.cargo, contato.nivel_hierarquico_id,
            contato.email, contato.empresa_id,
            contato.telefone, contato.telefone2, contato.linkedin,
            contato.contato_whatsapp, contato.tags, contato.observacoes,
            contato.reporta_a, contato.departamento_id
        ))
        novo_id = cur.fetchone()["id"]
        conn.commit()
        conn.close()

        return {"id": novo_id, "status": "criado", "mensagem": "Contato criado com sucesso"}

    except Exception as e:
        import traceback
        traceback.print_exc()   # imprime stacktrace completo no console
        print(f"❌ ERRO CRIAR CONTATO: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Erro ao criar contato: {str(e)}")

# ---------- OBTER POR ID ----------
@router.get("/{id}")
def obter_contato(
    id: int,
    current_user: dict = Depends(get_current_user)
):
    """Obtém um contato específico pelo ID"""
    try:
        conn = get_conn()
        cur = conn.cursor()
        cur.execute("SELECT * FROM contatos WHERE id = %s", (id,))
        row = cur.fetchone()
        conn.close()

        if not row:
            raise HTTPException(status_code=404, detail="Contato não encontrado")

        return dict(row)

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro ao obter contato: {str(e)}")

# ---------- ATUALIZAR ----------
@router.put("/{id}")
def atualizar_contato(
    id: int,
    contato: ContatoUpdate,
    current_user: dict = Depends(get_current_user)
):
    """Atualiza um contato existente (parcial ou completo)"""
    try:
        conn = get_conn()
        cur = conn.cursor()

        # Monta lista de campos enviados no JSON
        campos = []
        valores = []
        for campo, valor in contato.dict(exclude_unset=True).items():
            campos.append(f"{campo} = %s")
            valores.append(valor)

        if not campos:
            raise HTTPException(status_code=400, detail="Nenhum campo fornecido para atualização")

        valores.append(id)
        query = f"UPDATE contatos SET {', '.join(campos)}, updated_at = NOW() WHERE id = %s RETURNING id"
        cur.execute(query, tuple(valores))
        atualizado = cur.fetchone()
        conn.commit()
        conn.close()

        if not atualizado:
            raise HTTPException(status_code=404, detail="Contato não encontrado")

        return {"id": id, "status": "atualizado", "mensagem": "Contato atualizado com sucesso"}

    except Exception as e:
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"Erro ao atualizar contato: {str(e)}")

# ---------- DELETAR ----------
@router.delete("/{id}")
def deletar_contato(
    id: int,
    current_user: dict = Depends(get_current_user)
):
    """Deleta um contato pelo ID"""
    try:
        conn = get_conn()
        cur = conn.cursor()
        cur.execute("DELETE FROM contatos WHERE id = %s RETURNING id", (id,))
        deletado = cur.fetchone()
        conn.commit()
        conn.close()

        if not deletado:
            raise HTTPException(status_code=404, detail="Contato não encontrado")

        return {"id": id, "status": "deletado", "mensagem": "Contato deletado com sucesso"}

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro ao deletar contato: {str(e)}")
