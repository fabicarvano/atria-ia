# Checklist de Conformidade - API Atria

## 🎯 Objetivo
Este checklist garante que a API Atria esteja 100% conforme aos padrões estabelecidos no documento_dev, sem quebrar funcionalidades existentes.

---

## 📋 PRIORIDADE 1 - CRÍTICA (Impedem funcionamento completo)

### ✅ 1. Criar Módulo auxiliares.py
- [ ] **Status**: Pendente
- **Localização**: `/app/auxiliares.py`
- **O que fazer**: Criar arquivo com as 3 rotas documentadas
- **Por que**: Contas e contatos dependem de setores/categorias que não existem
- **Risco de quebra**: 🟢 Baixo (apenas adiciona funcionalidade)

**Código base para criar:**
```python
# /app/auxiliares.py
from fastapi import APIRouter, Depends, HTTPException
from auth import get_current_user
from database import get_conn

router = APIRouter(dependencies=[Depends(get_current_user)])

@router.get("/setores")
def listar_setores(current_user: dict = Depends(get_current_user)):
    """Lista todos os setores disponíveis"""
    try:
        conn = get_conn()
        cur = conn.cursor()
        cur.execute("SELECT id, nome FROM setores ORDER BY nome ASC")
        rows = cur.fetchall()
        conn.close()
        
        dados = [{"id": r["id"], "nome": r["nome"]} for r in rows]
        return {"total": len(dados), "dados": dados}
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro ao listar setores: {str(e)}")

@router.get("/categorias")
def listar_categorias(current_user: dict = Depends(get_current_user)):
    """Lista todas as categorias disponíveis"""
    # Implementação similar aos setores

@router.get("/departamentos")
def listar_departamentos(current_user: dict = Depends(get_current_user)):
    """Lista todos os departamentos disponíveis"""
    # Implementação similar aos setores
```

---

### ✅ 2. Criar Diretório /servicos/ e Mover Arquivos
- [X ] **Status**: ###EXECUTADO### 
- **O que fazer**: 
  1. Criar pasta `/app/servicos/`
  2. Criar arquivo `/app/servicos/__init__.py` (vazio)
  3. Mover `enriquecimento.py` para `/app/servicos/enriquecimento.py`
  4. Mover `enriquecimento_contato.py` para `/app/servicos/enriquecimento_contato.py`
- **Por que**: Padrão de organização definido no documento_dev
- **Risco de quebra**: 🟡 Médio (precisa ajustar importações)

**Comandos para executar:**
```bash
mkdir -p /app/servicos/
touch /app/servicos/__init__.py
mv /app/enriquecimento.py /app/servicos/
mv /app/enriquecimento_contato.py /app/servicos/
```

---

### ✅ 3. Corrigir Importações no main.py
- [ ] **Status**: ###EXECUTADO###
- **O que fazer**: Atualizar importações após mover arquivos
- **Por que**: Importações quebram após reorganização
- **Risco de quebra**: 🟡 Médio (API para de funcionar se não corrigir)

**Mudanças no main.py:**
```python
# ANTES (linhas 18-21)
from servicos import enriquecimento
from servicos import enriquecimento_router, enriquecimento_contato_router

# DEPOIS
from auxiliares import router as auxiliares_router
from servicos.enriquecimento import router as enriquecimento_router
from servicos.enriquecimento_contato import router as enriquecimento_contato_router

# ADICIONAR após linha 109
app.include_router(auxiliares_router, prefix="/api/v1/auxiliares", tags=["auxiliares"])

# CORRIGIR linha 111 (remover referência antiga)
# ANTES
app.include_router(enriquecimento.router, prefix="/api/v1/enriquecimento", tags=["enriquecimento"])
# DEPOIS
app.include_router(enriquecimento_router, prefix="/api/v1/enriquecimento", tags=["enriquecimento"])
```

---

### ✅ 4. Corrigir Importação de get_conn nos Arquivos de Serviços
- [ ] **Status**: Pendente
- **O que fazer**: Padronizar importação de `get_conn` de `database.py`
- **Por que**: Alguns arquivos definem função local, outros importam
- **Risco de quebra**: 🟢 Baixo (apenas padronização)

**Mudanças em `/app/servicos/enriquecimento.py`:**
```python
# REMOVER linhas 33-35
def get_conn():
    return psycopg2.connect(DATABASE_URL)

# ADICIONAR no topo (após outras importações)
from database import get_conn
```

---

## 📋 PRIORIDADE 2 - ALTA (Afetam qualidade e usabilidade)

### ✅ 5. Padronizar Validação de Email
- [ ] **Status**: Pendente
- **O que fazer**: Mover validação de email para modelo `ContatoCreate`
- **Por que**: Validação só existe no Update, não no Create
- **Risco de quebra**: 🟢 Baixo (apenas adiciona validação)

**Mudanças em `/app/contatos.py`:**
```python
# ADICIONAR no modelo ContatoCreate (após linha 24)
class ContatoCreate(BaseModel):
    # ... campos existentes ...
    
    @validator('email')
    def validar_email(cls, v):
        if '@' not in v:
            raise ValueError("Email inválido")
        return v
```

---

### ✅ 6. Corrigir Query de Contagem em contatos.py
- [ ] **Status**: Pendente
- **O que fazer**: Padronizar acesso ao resultado da query COUNT
- **Por que**: Inconsistência entre `["count"]` e `[0]`
- **Risco de quebra**: 🟡 Médio (pode quebrar paginação)

**Mudanças em `/app/contatos.py` linha 58:**
```python
# ANTES
cur.execute("SELECT COUNT(*) FROM contatos")
total = cur.fetchone()["count"]

# DEPOIS (opção 1 - mais segura)
cur.execute("SELECT COUNT(*) as total FROM contatos")
result = cur.fetchone()
total = result['total'] if result else 0

# OU (opção 2 - mais simples)
cur.execute("SELECT COUNT(*) FROM contatos")
total = cur.fetchone()[0]
```

---

### ✅ 7. Corrigir Query de Contagem em contas.py
- [ ] **Status**: Pendente
- **O que fazer**: Mesmo problema do contatos.py
- **Por que**: Inconsistência similar
- **Risco de quebra**: 🟡 Médio (pode quebrar paginação)

**Mudanças em `/app/contas.py` linha 156:**
```python
# ANTES
cur.execute("SELECT COUNT(*) as total FROM contas")
result = cur.fetchone()
total = result['total'] if result else 0

# DEPOIS (padronizar com contatos)
cur.execute("SELECT COUNT(*) FROM contas")
total = cur.fetchone()[0]
```

---

## 📋 PRIORIDADE 3 - MÉDIA (Melhorias de qualidade)

### ✅ 8. Melhorar Docstrings em contatos.py
- [ ] **Status**: Pendente
- **O que fazer**: Adicionar docstrings detalhadas seguindo padrão do contas.py
- **Por que**: Documentação inconsistente entre módulos
- **Risco de quebra**: 🟢 Baixo (apenas documentação)

**Exemplo para rota criar_contato:**
```python
@router.post("/")
def criar_contato(
    contato: ContatoCreate,
    current_user: dict = Depends(get_current_user)
):
    """
    Cria um novo contato no sistema
    
    - **nome**: Nome completo do contato (obrigatório)
    - **cargo**: Cargo/função do contato (obrigatório)
    - **nivel_hierarquico_id**: ID do nível hierárquico (obrigatório)
    - **email**: Email único do contato (obrigatório)
    - **empresa_id**: ID da empresa vinculada (obrigatório)
    - **telefone**: Telefone principal (opcional)
    - **linkedin**: URL do perfil LinkedIn (opcional)
    
    Retorna:
    - ID do contato criado e status de sucesso
    
    Erros:
    - 400: Email já existe no sistema
    - 403: Token JWT inválido
    - 422: Dados de entrada inválidos
    - 500: Erro interno do servidor
    """
```

---

### ✅ 9. Adicionar Logs Consistentes
- [ ] **Status**: Pendente
- **O que fazer**: Padronizar logs de erro em todos os módulos
- **Por que**: Facilita debugging e monitoramento
- **Risco de quebra**: 🟢 Baixo (apenas adiciona logs)

**Padrão a seguir (já usado em alguns arquivos):**
```python
except Exception as e:
    print(f"❌ ERRO CRIAR CONTATO: {str(e)}")
    raise HTTPException(status_code=500, detail=f"Erro ao criar contato: {str(e)}")
```

---

### ✅ 10. Corrigir Acesso ao Nome da Conta em contas.py
- [ ] **Status**: Pendente
- **O que fazer**: Corrigir acesso ao campo nome na função deletar_conta
- **Por que**: Código atual pode quebrar dependendo do driver do banco
- **Risco de quebra**: 🟡 Médio (função delete pode falhar)

**Mudanças em `/app/contas.py` linha 650:**
```python
# ANTES
cur.execute("SELECT nome FROM contas WHERE id = %s", (conta_id,))
result = cur.fetchone()
nome_conta = result[0]  # Acesso por índice pode falhar

# DEPOIS (mais seguro)
cur.execute("SELECT nome FROM contas WHERE id = %s", (conta_id,))
result = cur.fetchone()
nome_conta = result["nome"] if result else "Conta desconhecida"
```

---

## 📋 VERIFICAÇÕES FINAIS

### ✅ 11. Testar Todas as Rotas Após Mudanças
- [ ] **Status**: Pendente
- **O que fazer**: Executar testes básicos em todas as rotas
- **Por que**: Garantir que nada quebrou
- **Risco de quebra**: N/A (é o teste)

**Comandos de teste básico:**
```bash
# 1. Testar login
curl -X POST "http://127.0.0.1:8000/api/v1/auth/login" \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@atria.com","password":"admin123"}'

# 2. Testar auxiliares (NOVO)
curl -X GET "http://127.0.0.1:8000/api/v1/auxiliares/setores" \
  -H "Authorization: Bearer TOKEN"

# 3. Testar contas
curl -X GET "http://127.0.0.1:8000/api/v1/contas/" \
  -H "Authorization: Bearer TOKEN"

# 4. Testar contatos
curl -X GET "http://127.0.0.1:8000/api/v1/contatos/" \
  -H "Authorization: Bearer TOKEN"

# 5. Testar enriquecimento
curl -X POST "http://127.0.0.1:8000/api/v1/enriquecimento/cnpj/418" \
  -H "Authorization: Bearer TOKEN"
```

---

### ✅ 12. Verificar Documentação OpenAPI
- [ ] **Status**: Pendente
- **O que fazer**: Acessar `/docs` e verificar se todas as rotas aparecem
- **Por que**: Garantir que a documentação automática está funcionando
- **Risco de quebra**: 🟢 Baixo (apenas verificação)

**Como verificar:**
1. Acessar `http://127.0.0.1:8000/docs`
2. Verificar se aparecem os módulos: auth, auxiliares, contas, contatos, enriquecimento
3. Testar uma rota de cada módulo pela interface

---

## 🚨 CUIDADOS IMPORTANTES

### ⚠️ Ordem de Execução
**SEMPRE seguir esta ordem para evitar quebras:**
1. Criar auxiliares.py primeiro
2. Criar diretório servicos/
3. Mover arquivos
4. Corrigir importações no main.py
5. Testar se API ainda funciona
6. Fazer demais correções

### ⚠️ Backup Recomendado
Antes de começar, fazer backup dos arquivos:
```bash
cp -r /app /app_backup_$(date +%Y%m%d_%H%M%S)
```

### ⚠️ Teste Incremental
Após cada mudança crítica (1-4), reiniciar a API e testar:
```bash
# Reiniciar API
pkill -f "uvicorn"
cd /app && uvicorn main:app --reload --host 0.0.0.0 --port 8000

# Testar login básico
curl -X POST "http://127.0.0.1:8000/api/v1/auth/login" \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@atria.com","password":"admin123"}'
```

---

## 📊 Progresso Geral

**Total de itens**: 12  
**Concluídos**: 0  
**Pendentes**: 12  

**Estimativa de tempo:**
- Prioridade 1 (Crítica): 2-4 horas
- Prioridade 2 (Alta): 1-2 horas  
- Prioridade 3 (Média): 1-2 horas
- **Total**: 4-8 horas

---

## ✅ Checklist de Validação Final

Após completar todos os itens, verificar:

- [ ] API inicia sem erros
- [ ] Todas as rotas respondem (login, auxiliares, contas, contatos, enriquecimento)
- [ ] Documentação `/docs` mostra todos os módulos
- [ ] Logs aparecem corretamente no console
- [ ] Estrutura de diretórios está conforme padrão
- [ ] Importações estão corretas
- [ ] Validações funcionam (email, CNPJ, etc.)

**Status Final**: 🔴 Pendente / 🟡 Em Progresso / 🟢 Completo
