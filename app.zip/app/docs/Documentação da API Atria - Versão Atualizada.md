# Documentação da API Atria - Versão Atualizada

## Visão Geral

A API Atria utiliza um sistema de autenticação em duas camadas para garantir segurança e controle de acesso. Esta documentação reflete o estado atual da implementação baseada na análise dos arquivos Python fornecidos.

### Sistema de Autenticação

- **X-API-KEY**: Obrigatória para todas as rotas externas (exceto login)
- **JWT Token**: Obrigatório para rotas que manipulam dados sensíveis

### Configuração Base

| Parâmetro | Valor |
|-----------|-------|
| **URL Base** | `https://api.atria.ia.br` |
| **X-API-KEY** | `4c3c4f0333937787a316fd5240e0999ba17fc3e33646289f8d8b95b97b2c6a4e` |
| **Formato de Data** | ISO 8601 (UTC) |
| **Versionamento** | `/api/v1/` |

---

## Módulo: Autenticação

### 1. Login
**Obter token de acesso para usar a API**

- **Método**: `POST`
- **Rota Externa**: `https://api.atria.ia.br/api/v1/auth/login`
- **Rota Interna**: `http://127.0.0.1:8000/api/v1/auth/login`
- **Autenticação**: Nenhuma (única rota sem X-API-KEY)

**Inputs (JSON):**
```json
{
  "email": "string (obrigatório)",
  "password": "string (obrigatório)"
}
```

**Exemplo Externo:**
```bash
curl -X POST "https://api.atria.ia.br/api/v1/auth/login" \
     -H "Content-Type: application/json" \
     -d '{
       "email": "admin@atria.com",
       "password": "admin123"
     }'
```

**Resposta (200):**
```json
{
  "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "token_type": "bearer"
}
```

**Erros:**
- `401`: Credenciais inválidas

---

### 2. Dados do Usuário
**Retorna informações do usuário logado**

- **Método**: `GET`
- **Rota Externa**: `https://api.atria.ia.br/api/v1/auth/me`
- **Rota Interna**: `http://127.0.0.1:8000/api/v1/auth/me`
- **Autenticação**: X-API-KEY + JWT Token

**Inputs:** Nenhum

**Exemplo Externo:**
```bash
curl -X GET "https://api.atria.ia.br/api/v1/auth/me" \
     -H "x-api-key: 4c3c4f0333937787a316fd5240e0999ba17fc3e33646289f8d8b95b97b2c6a4e" \
     -H "Authorization: Bearer SEU_JWT_TOKEN"
```

**Resposta (200):**
```json
{
  "id": 1,
  "nome": "Admin",
  "email": "admin@atria.com",
  "role": "admin",
  "is_active": true
}
```

**Erros:**
- `401`: Token JWT inválido ou expirado
- `403`: API Key inválida

---

## Módulo: Health Check

### 1. Status da API
**Verifica se a API está funcionando**

- **Método**: `GET`
- **Rota Externa**: `https://api.atria.ia.br/api/v1/health`
- **Rota Interna**: `http://127.0.0.1:8000/api/v1/health`
- **Autenticação**: X-API-KEY (externa) / Nenhuma (interna)

**Inputs:** Nenhum

**Exemplo Externo:**
```bash
curl -X GET "https://api.atria.ia.br/api/v1/health" \
     -H "x-api-key: 4c3c4f0333937787a316fd5240e0999ba17fc3e33646289f8d8b95b97b2c6a4e"
```

**Resposta (200):**
```json
{
  "status": "ok"
}
```

---

## Módulo: Auxiliares

> **⚠️ ATENÇÃO**: Este módulo está documentado mas **não foi implementado** ainda. As rotas abaixo precisam ser criadas conforme análise de conformidade.

### 1. Listar Setores
**Retorna todos os setores disponíveis**

- **Método**: `GET`
- **Rota**: `/api/v1/auxiliares/setores`
- **Status**: 🔴 **NÃO IMPLEMENTADO**

### 2. Listar Categorias
**Retorna todas as categorias disponíveis**

- **Método**: `GET`
- **Rota**: `/api/v1/auxiliares/categorias`
- **Status**: 🔴 **NÃO IMPLEMENTADO**

### 3. Listar Departamentos
**Retorna todos os departamentos disponíveis**

- **Método**: `GET`
- **Rota**: `/api/v1/auxiliares/departamentos`
- **Status**: 🔴 **NÃO IMPLEMENTADO**

---

## Módulo: Contas

### 1. Listar Contas
**Lista todas as contas com paginação**

- **Método**: `GET`
- **Rota Externa**: `https://api.atria.ia.br/api/v1/contas/`
- **Rota Interna**: `http://127.0.0.1:8000/api/v1/contas/`
- **Autenticação**: X-API-KEY + JWT Token

**Parâmetros de Query:**
- `page` (opcional): Número da página (padrão: 1)
- `limit` (opcional): Itens por página (padrão: 50, máximo: 100)

**Exemplo Externo:**
```bash
curl -X GET "https://api.atria.ia.br/api/v1/contas/?page=1&limit=50" \
     -H "x-api-key: 4c3c4f0333937787a316fd5240e0999ba17fc3e33646289f8d8b95b97b2c6a4e" \
     -H "Authorization: Bearer SEU_JWT_TOKEN"
```

**Resposta (200):**
```json
{
  "total": 1250,
  "page": 1,
  "limit": 50,
  "pages": 25,
  "dados": [
    {
      "id": 418,
      "nome": "Brava Energia",
      "cnpj": "12091809000155",
      "setor_id": 1,
      "setor_nome": "Tecnologia",
      "categoria_id": 2,
      "categoria_nome": "Federal",
      "site": "bravaenergia.com.br",
      "linkedin": "linkedin.com/company/brava-energia",
      "razao_social": "BRAVA ENERGIA S.A",
      "funcionarios": 500,
      "estado": "RJ",
      "cidade": "Rio de Janeiro",
      "criado_em": "2024-01-15T10:30:00",
      "atualizado_em": "2024-03-20T14:45:00"
    }
  ]
}
```

**Erros:**
- `403`: API Key inválida ou Token JWT inválido
- `422`: Parâmetros de paginação inválidos
- `500`: Erro interno do servidor

---

### 2. Criar Conta
**Cria uma nova conta no sistema**

- **Método**: `POST`
- **Rota Externa**: `https://api.atria.ia.br/api/v1/contas/`
- **Rota Interna**: `http://127.0.0.1:8000/api/v1/contas/`
- **Autenticação**: X-API-KEY + JWT Token

**Inputs (JSON):**
```json
{
  "nome": "string",           // Obrigatório, mín. 2 caracteres
  "cnpj": "string",           // Obrigatório, 14 dígitos
  "setor_id": "integer",      // Obrigatório, deve existir na tabela setores
  "categoria_id": "integer",  // Obrigatório, deve existir na tabela categorias
  "site": "string",           // Opcional, URL limpa automaticamente
  "linkedin": "string"        // Opcional, deve conter "linkedin.com"
}
```

**Exemplo Externo:**
```bash
curl -X POST "https://api.atria.ia.br/api/v1/contas/" \
     -H "x-api-key: 4c3c4f0333937787a316fd5240e0999ba17fc3e33646289f8d8b95b97b2c6a4e" \
     -H "Authorization: Bearer SEU_JWT_TOKEN" \
     -H "Content-Type: application/json" \
     -d '{
       "nome": "Tech Solutions LTDA",
       "cnpj": "12345678000195",
       "setor_id": 1,
       "categoria_id": 2,
       "site": "www.techsolutions.com.br",
       "linkedin": "linkedin.com/company/tech-solutions"
     }'
```

**Resposta (201):**
```json
{
  "id": 1919,
  "status": "criado",
  "mensagem": "Conta criada com sucesso",
  "dados": {
    "id": 1919,
    "nome": "Tech Solutions LTDA",
    "cnpj": "12345678000195",
    "setor_id": 1,
    "setor_nome": "Tecnologia",
    "categoria_id": 2,
    "categoria_nome": "Federal",
    "site": "techsolutions.com.br",
    "linkedin": "linkedin.com/company/tech-solutions",
    "criado_em": "2025-09-29T13:30:00"
  }
}
```

**Erros:**
- `400`: CNPJ já existe no sistema
- `403`: API Key inválida ou Token JWT inválido
- `404`: Setor ou categoria não encontrados
- `422`: Dados de entrada inválidos (validação Pydantic)
- `500`: Erro interno do servidor

---

### 3. Obter Conta Específica
**Retorna os dados de uma conta específica**

- **Método**: `GET`
- **Rota Externa**: `https://api.atria.ia.br/api/v1/contas/{conta_id}`
- **Rota Interna**: `http://127.0.0.1:8000/api/v1/contas/{conta_id}`
- **Autenticação**: X-API-KEY + JWT Token

**Inputs:**
- `conta_id` (path parameter): ID da conta

**Exemplo Externo:**
```bash
curl -X GET "https://api.atria.ia.br/api/v1/contas/418" \
     -H "x-api-key: 4c3c4f0333937787a316fd5240e0999ba17fc3e33646289f8d8b95b97b2c6a4e" \
     -H "Authorization: Bearer SEU_JWT_TOKEN"
```

**Resposta (200):**
```json
{
  "id": 418,
  "nome": "Brava Energia",
  "razao_social": "BRAVA ENERGIA S.A",
  "cnpj": "12091809000155",
  "site": "bravaenergia.com.br",
  "linkedin": "linkedin.com/company/brava-energia",
  "funcionarios": 500,
  "estado": "RJ",
  "cidade": "Rio de Janeiro",
  "endereco": "Av. das Américas, 3434",
  "setor_id": 1,
  "setor_nome": "Tecnologia",
  "categoria_id": 2,
  "categoria_nome": "Federal",
  "descricao": "Empresa de energia renovável",
  "tipo_estabelecimento": "matriz",
  "capital_social": 11971587907.00,
  "descricao_oficial": "Atividades de exploração de petróleo e gás natural",
  "numero_seguidores": 15420,
  "logo_url": "https://media.licdn.com/dms/image/...",
  "inconsistencias": [],
  "criado_em": "2024-01-15T10:30:00",
  "atualizado_em": "2024-03-20T14:45:00",
  "criado_por": "admin@atria.com"
}
```

**Erros:**
- `403`: API Key inválida ou Token JWT inválido
- `404`: Conta não encontrada
- `500`: Erro interno do servidor

---

### 4. Atualizar Conta
**Atualiza os dados de uma conta existente (atualização parcial)**

- **Método**: `PUT`
- **Rota Externa**: `https://api.atria.ia.br/api/v1/contas/{conta_id}`
- **Rota Interna**: `http://127.0.0.1:8000/api/v1/contas/{conta_id}`
- **Autenticação**: X-API-KEY + JWT Token

**Inputs:**
- `conta_id` (path parameter): ID da conta
- **Body (JSON)**: Campos a serem atualizados (todos opcionais)

```json
{
  "nome": "string",           // Opcional, mín. 2 caracteres
  "cnpj": "string",           // Opcional, 14 dígitos, deve ser único
  "setor_id": "integer",      // Opcional, deve existir na tabela setores
  "categoria_id": "integer",  // Opcional, deve existir na tabela categorias
  "site": "string",           // Opcional, URL limpa automaticamente
  "linkedin": "string"        // Opcional, deve conter "linkedin.com"
}
```

**Exemplo Externo:**
```bash
curl -X PUT "https://api.atria.ia.br/api/v1/contas/1918" \
     -H "x-api-key: 4c3c4f0333937787a316fd5240e0999ba17fc3e33646289f8d8b95b97b2c6a4e" \
     -H "Authorization: Bearer SEU_JWT_TOKEN" \
     -H "Content-Type: application/json" \
     -d '{
       "nome": "Fabio Carvano Atualizado",
       "site": "www.fabiocarvano.com"
     }'
```

**Resposta (200):**
```json
{
  "id": 1918,
  "status": "atualizado",
  "mensagem": "Conta atualizada com sucesso",
  "dados": {
    "id": 1918,
    "nome": "Fabio Carvano Atualizado",
    "cnpj": "12345678000195",
    "site": "fabiocarvano.com",
    "setor_id": 1,
    "setor_nome": "Tecnologia",
    "categoria_id": 2,
    "categoria_nome": "Federal",
    "atualizado_em": "2025-09-29T13:45:00"
  }
}
```

**Erros:**
- `400`: CNPJ já existe em outra conta ou nenhum campo fornecido
- `403`: API Key inválida ou Token JWT inválido
- `404`: Conta, setor ou categoria não encontrados
- `422`: Dados de entrada inválidos
- `500`: Erro interno do servidor

---

### 5. Deletar Conta
**Remove uma conta do sistema**

- **Método**: `DELETE`
- **Rota Externa**: `https://api.atria.ia.br/api/v1/contas/{conta_id}`
- **Rota Interna**: `http://127.0.0.1:8000/api/v1/contas/{conta_id}`
- **Autenticação**: X-API-KEY + JWT Token

**Inputs:**
- `conta_id` (path parameter): ID da conta

**Exemplo Externo:**
```bash
curl -X DELETE "https://api.atria.ia.br/api/v1/contas/1919" \
     -H "x-api-key: 4c3c4f0333937787a316fd5240e0999ba17fc3e33646289f8d8b95b97b2c6a4e" \
     -H "Authorization: Bearer SEU_JWT_TOKEN"
```

**Resposta (200):**
```json
{
  "id": 1919,
  "status": "deletado",
  "mensagem": "Conta 'Tech Solutions LTDA' deletada com sucesso"
}
```

**Erros:**
- `400`: Conta possui contatos vinculados (deve deletar contatos primeiro)
- `403`: API Key inválida ou Token JWT inválido
- `404`: Conta não encontrada
- `500`: Erro interno do servidor

---

### 6. Criar Contas em Lote (NOVA FUNCIONALIDADE)
**Upload de arquivo CSV para criação em massa**

- **Método**: `POST`
- **Rota Externa**: `https://api.atria.ia.br/api/v1/contas/lote`
- **Rota Interna**: `http://127.0.0.1:8000/api/v1/contas/lote`
- **Autenticação**: X-API-KEY + JWT Token

**Inputs:**
- **arquivo**: Arquivo CSV (multipart/form-data)

**Formato do CSV:**
```csv
nome,cnpj,setor_id,categoria_id,site,linkedin
Empresa A,12345678000195,1,2,www.empresaa.com,linkedin.com/company/empresaa
Empresa B,98765432000187,2,1,,linkedin.com/company/empresab
Empresa C,11111111000111,1,1,empresac.com.br,
```

**Exemplo Externo:**
```bash
curl -X POST "https://api.atria.ia.br/api/v1/contas/lote" \
     -H "x-api-key: 4c3c4f0333937787a316fd5240e0999ba17fc3e33646289f8d8b95b97b2c6a4e" \
     -H "Authorization: Bearer SEU_JWT_TOKEN" \
     -F "arquivo=@contas.csv"
```

**Resposta (200):**
```json
{
  "status": "processado",
  "total_processadas": 100,
  "contas_criadas": 85,
  "erros": 15,
  "mensagem": "85 contas criadas com sucesso",
  "dados_criadas": [
    {
      "id": 1920,
      "nome": "Empresa A",
      "cnpj": "12345678000195"
    }
  ],
  "detalhes_erros": [
    "Linha 5: CNPJ 98765432000187 já está cadastrado",
    "Linha 12: Setor ID 999 não encontrado"
  ]
}
```

**Erros:**
- `400`: Arquivo CSV inválido ou vazio
- `403`: API Key inválida ou Token JWT inválido
- `422`: Formato de arquivo não suportado
- `500`: Erro interno do servidor

---

## Módulo: Contatos

### 1. Listar Contatos
**Lista todos os contatos cadastrados com paginação**

- **Método**: `GET`
- **Rota Externa**: `https://api.atria.ia.br/api/v1/contatos/`
- **Rota Interna**: `http://127.0.0.1:8000/api/v1/contatos/`
- **Autenticação**: X-API-KEY + JWT Token

**Parâmetros de Query:**
- `page` (opcional): Número da página (padrão: 1)
- `limit` (opcional): Itens por página (padrão: 30, máximo: 100)

**Exemplo Externo:**
```bash
curl -X GET "https://api.atria.ia.br/api/v1/contatos/?page=1&limit=30" \
     -H "x-api-key: 4c3c4f0333937787a316fd5240e0999ba17fc3e33646289f8d8b95b97b2c6a4e" \
     -H "Authorization: Bearer SEU_JWT_TOKEN"
```

**Resposta (200):**
```json
{
  "total": 120,
  "page": 1,
  "limit": 30,
  "pages": 4,
  "dados": [
    {
      "id": 586,
      "nome": "Carlos Silva",
      "cargo": "Analista de Redes",
      "nivel_hierarquico_id": 1,
      "email": "carlos.silva@exemplo.com",
      "empresa_id": 451,
      "telefone": "21999990000",
      "linkedin": "https://linkedin.com/in/carlos-silva",
      "contato_whatsapp": true,
      "tags": "rede,seguranca",
      "observacoes": "Contato de teste via API",
      "departamento_id": 1,
      "created_at": "2025-09-29T13:30:00",
      "updated_at": "2025-09-29T14:00:00"
    }
  ]
}
```

**Erros:**
- `403`: API Key inválida ou Token JWT inválido
- `422`: Parâmetros de paginação inválidos
- `500`: Erro interno do servidor

---

### 2. Criar Contato
**Cria um novo contato no sistema**

- **Método**: `POST`
- **Rota Externa**: `https://api.atria.ia.br/api/v1/contatos/`
- **Rota Interna**: `http://127.0.0.1:8000/api/v1/contatos/`
- **Autenticação**: X-API-KEY + JWT Token

**Inputs (JSON):**
```json
{
  "nome": "string",                    // Obrigatório
  "cargo": "string",                   // Obrigatório
  "nivel_hierarquico_id": "integer",   // Obrigatório
  "email": "string",                   // Obrigatório, único
  "empresa_id": "integer",             // Obrigatório
  "telefone": "string",                // Opcional
  "telefone2": "string",               // Opcional
  "linkedin": "string",                // Opcional
  "contato_whatsapp": "boolean",       // Opcional, padrão: false
  "tags": "string",                    // Opcional
  "observacoes": "string",             // Opcional
  "reporta_a": "integer",              // Opcional
  "departamento_id": "integer"         // Opcional
}
```

**Exemplo Externo:**
```bash
curl -X POST "https://api.atria.ia.br/api/v1/contatos/" \
     -H "x-api-key: 4c3c4f0333937787a316fd5240e0999ba17fc3e33646289f8d8b95b97b2c6a4e" \
     -H "Authorization: Bearer SEU_JWT_TOKEN" \
     -H "Content-Type: application/json" \
     -d '{
       "nome": "Carlos Silva",
       "cargo": "Analista de Redes",
       "nivel_hierarquico_id": 1,
       "email": "carlos.silva@exemplo.com",
       "empresa_id": 451,
       "telefone": "21999990000",
       "linkedin": "https://linkedin.com/in/carlos-silva",
       "contato_whatsapp": true,
       "tags": "rede,seguranca",
       "observacoes": "Contato de teste via API",
       "departamento_id": 1
     }'
```

**Resposta (201):**
```json
{
  "id": 586,
  "status": "criado",
  "mensagem": "Contato criado com sucesso"
}
```

**Erros:**
- `400`: Email já existe no sistema
- `403`: API Key inválida ou Token JWT inválido
- `422`: Dados de entrada inválidos
- `500`: Erro interno do servidor

---

### 3. Obter Contato Específico
**Retorna os dados de um contato específico**

- **Método**: `GET`
- **Rota Externa**: `https://api.atria.ia.br/api/v1/contatos/{id}`
- **Rota Interna**: `http://127.0.0.1:8000/api/v1/contatos/{id}`
- **Autenticação**: X-API-KEY + JWT Token

**Inputs:**
- `id` (path parameter): ID do contato

**Exemplo Externo:**
```bash
curl -X GET "https://api.atria.ia.br/api/v1/contatos/586" \
     -H "x-api-key: 4c3c4f0333937787a316fd5240e0999ba17fc3e33646289f8d8b95b97b2c6a4e" \
     -H "Authorization: Bearer SEU_JWT_TOKEN"
```

**Resposta (200):**
```json
{
  "id": 586,
  "nome": "Carlos Silva",
  "cargo": "Analista de Redes",
  "nivel_hierarquico_id": 1,
  "email": "carlos.silva@exemplo.com",
  "empresa_id": 451,
  "telefone": "21999990000",
  "linkedin": "https://linkedin.com/in/carlos-silva",
  "contato_whatsapp": true,
  "tags": "rede,seguranca",
  "observacoes": "Contato de teste via API",
  "departamento_id": 1,
  "created_at": "2025-09-29T13:30:00",
  "updated_at": "2025-09-29T14:00:00"
}
```

**Erros:**
- `403`: API Key inválida ou Token JWT inválido
- `404`: Contato não encontrado
- `500`: Erro interno do servidor

---

### 4. Atualizar Contato
**Atualiza os dados de um contato existente (atualização parcial)**

- **Método**: `PUT`
- **Rota Externa**: `https://api.atria.ia.br/api/v1/contatos/{id}`
- **Rota Interna**: `http://127.0.0.1:8000/api/v1/contatos/{id}`
- **Autenticação**: X-API-KEY + JWT Token

**Inputs:**
- `id` (path parameter): ID do contato
- **Body (JSON)**: Campos a serem atualizados (todos opcionais)

**Exemplo Externo:**
```bash
curl -X PUT "https://api.atria.ia.br/api/v1/contatos/586" \
     -H "x-api-key: 4c3c4f0333937787a316fd5240e0999ba17fc3e33646289f8d8b95b97b2c6a4e" \
     -H "Authorization: Bearer SEU_JWT_TOKEN" \
     -H "Content-Type: application/json" \
     -d '{
       "cargo": "Gestor de Redes",
       "departamento_id": 3
     }'
```

**Resposta (200):**
```json
{
  "id": 586,
  "status": "atualizado",
  "mensagem": "Contato atualizado com sucesso"
}
```

**Erros:**
- `400`: Email já existe em outro contato ou nenhum campo fornecido
- `403`: API Key inválida ou Token JWT inválido
- `404`: Contato não encontrado
- `422`: Dados de entrada inválidos
- `500`: Erro interno do servidor

---

### 5. Deletar Contato
**Remove um contato do sistema**

- **Método**: `DELETE`
- **Rota Externa**: `https://api.atria.ia.br/api/v1/contatos/{id}`
- **Rota Interna**: `http://127.0.0.1:8000/api/v1/contatos/{id}`
- **Autenticação**: X-API-KEY + JWT Token

**Inputs:**
- `id` (path parameter): ID do contato

**Exemplo Externo:**
```bash
curl -X DELETE "https://api.atria.ia.br/api/v1/contatos/586" \
     -H "x-api-key: 4c3c4f0333937787a316fd5240e0999ba17fc3e33646289f8d8b95b97b2c6a4e" \
     -H "Authorization: Bearer SEU_JWT_TOKEN"
```

**Resposta (200):**
```json
{
  "id": 586,
  "status": "deletado",
  "mensagem": "Contato removido com sucesso"
}
```

**Erros:**
- `403`: API Key inválida ou Token JWT inválido
- `404`: Contato não encontrado
- `500`: Erro interno do servidor

---

## Módulo: Enriquecimento

### 1. Enriquecer com CNPJ
**Busca dados da Receita Federal pelo CNPJ da conta**

- **Método**: `POST`
- **Rota Externa**: `https://api.atria.ia.br/api/v1/enriquecimento/cnpj/{conta_id}`
- **Rota Interna**: `http://127.0.0.1:8000/api/v1/enriquecimento/cnpj/{conta_id}`
- **Autenticação**: X-API-KEY + JWT Token

**Inputs:**
- `conta_id` (path parameter): ID da conta a ser enriquecida

**Exemplo Externo:**
```bash
curl -X POST "https://api.atria.ia.br/api/v1/enriquecimento/cnpj/418" \
     -H "x-api-key: 4c3c4f0333937787a316fd5240e0999ba17fc3e33646289f8d8b95b97b2c6a4e" \
     -H "Authorization: Bearer SEU_JWT_TOKEN"
```

**Resposta (200):**
```json
{
  "status": "ok",
  "conta_id": 418,
  "nome": "Brava Energia",
  "cnpj": "12091809000155",
  "razao_social": "BRAVA ENERGIA S.A",
  "tipo_estabelecimento": "matriz",
  "cidade": "RIO DE JANEIRO",
  "estado": "RJ",
  "capital_social": "11971587907.00",
  "cnae_code": "0600-0/01",
  "cnae_text": "Extração de petróleo e gás natural",
  "email": "contato@bravaenergia.com.br"
}
```

**Erros:**
- `400`: Conta sem CNPJ cadastrado
- `403`: API Key inválida ou Token JWT inválido
- `404`: Conta não encontrada
- `500`: Erro interno do servidor ou na consulta ReceitaWS

---

### 2. Enriquecer com LinkedIn (Conta)
**Busca dados do LinkedIn para uma conta específica via Apify**

- **Método**: `POST`
- **Rota Externa**: `https://api.atria.ia.br/api/v1/enriquecimento/linkedin/{conta_id}`
- **Rota Interna**: `http://127.0.0.1:8000/api/v1/enriquecimento/linkedin/{conta_id}`
- **Autenticação**: X-API-KEY + JWT Token

> **⚠️ NOTA**: A implementação atual difere da documentação original. Opera sobre um único `conta_id` em vez de uma lista de IDs.

**Inputs:**
- `conta_id` (path parameter): ID da conta a ser enriquecida

**Exemplo Externo:**
```bash
curl -X POST "https://api.atria.ia.br/api/v1/enriquecimento/linkedin/418" \
     -H "x-api-key: 4c3c4f0333937787a316fd5240e0999ba17fc3e33646289f8d8b95b97b2c6a4e" \
     -H "Authorization: Bearer SEU_JWT_TOKEN"
```

**Resposta (200):**
```json
{
  "status": "ok",
  "conta_id": 418,
  "empresa_principal": {
    "linkedin": "linkedin.com/company/brava-energia",
    "funcionarios": 500,
    "numero_seguidores": 15420,
    "logo_url": "https://media.licdn.com/dms/image/...",
    "industria": "Oil & Energy",
    "descricao_oficial": "Empresa brasileira de energia renovável...",
    "especialidade": "energia renovável, sustentabilidade, inovação",
    "site": "bravaenergia.com.br"
  },
  "similares_inseridas": 12,
  "total_similares_encontradas": 15
}
```

**Erros:**
- `403`: API Key inválida ou Token JWT inválido
- `404`: Conta não encontrada
- `500`: Erro interno do servidor ou na API Apify

---

### 3. Validar Inconsistências (NOVA FUNCIONALIDADE)
**Valida e atualiza o campo de inconsistências de uma conta**

- **Método**: `POST`
- **Rota Externa**: `https://api.atria.ia.br/api/v1/enriquecimento/validar-inconsistencias/{conta_id}`
- **Rota Interna**: `http://127.0.0.1:8000/api/v1/enriquecimento/validar-inconsistencias/{conta_id}`
- **Autenticação**: X-API-KEY + JWT Token

**Regras de Validação:**
- **Falha no enriquecimento**: quando não existe `descricao_oficial`
- **Descrição inconsistente**: quando descrições não correspondem à mesma empresa
- **CNPJ de filial**: quando CNPJ não é matriz (posições 9-12 ≠ "0001")
- **Indústria não informada**: quando campo `industria` está vazio
- **Site não encontrado**: quando campo `site` está vazio
- **Site inconsistente**: quando site não corresponde à descrição oficial

**Inputs:**
- `conta_id` (path parameter): ID da conta a ser validada

**Exemplo Externo:**
```bash
curl -X POST "https://api.atria.ia.br/api/v1/enriquecimento/validar-inconsistencias/418" \
     -H "x-api-key: 4c3c4f0333937787a316fd5240e0999ba17fc3e33646289f8d8b95b97b2c6a4e" \
     -H "Authorization: Bearer SEU_JWT_TOKEN"
```

**Resposta (200):**
```json
{
  "status": "ok",
  "conta_id": 418,
  "inconsistencias": [
    "CNPJ cadastrado de filial",
    "Site inconsistente com descrição"
  ]
}
```

**Erros:**
- `403`: API Key inválida ou Token JWT inválido
- `404`: Conta não encontrada
- `500`: Erro interno do servidor

---

### 4. Padronizar Setor (NOVA FUNCIONALIDADE)
**Mapeia uma indústria (string) para um setor_id padrão usando IA**

- **Método**: `POST`
- **Rota Externa**: `https://api.atria.ia.br/api/v1/enriquecimento/padronizar-setor`
- **Rota Interna**: `http://127.0.0.1:8000/api/v1/enriquecimento/padronizar-setor`
- **Autenticação**: X-API-KEY + JWT Token

**Inputs (JSON):**
```json
{
  "nome_industria": "string"  // Nome da indústria a ser mapeada
}
```

**Exemplo Externo:**
```bash
curl -X POST "https://api.atria.ia.br/api/v1/enriquecimento/padronizar-setor" \
     -H "x-api-key: 4c3c4f0333937787a316fd5240e0999ba17fc3e33646289f8d8b95b97b2c6a4e" \
     -H "Authorization: Bearer SEU_JWT_TOKEN" \
     -H "Content-Type: application/json" \
     -d '{
       "nome_industria": "Oil & Energy"
     }'
```

**Resposta (200):**
```json
{
  "status": "ok",
  "nome_industria": "Oil & Energy",
  "setor_id": 5,
  "nome_setor": "Energia",
  "mapeamento_criado": true,
  "fonte": "mapeamento_ia"
}
```

**Erros:**
- `400`: Nome da indústria não pode estar vazio
- `403`: API Key inválida ou Token JWT inválido
- `500`: Erro interno do servidor

---

### 5. Limpar Campos Vazios (NOVA FUNCIONALIDADE)
**Converte strings vazias em NULL para uma conta específica**

- **Método**: `POST`
- **Rota Externa**: `https://api.atria.ia.br/api/v1/enriquecimento/limpar-campos-vazios/{conta_id}`
- **Rota Interna**: `http://127.0.0.1:8000/api/v1/enriquecimento/limpar-campos-vazios/{conta_id}`
- **Autenticação**: X-API-KEY + JWT Token

**Inputs:**
- `conta_id` (path parameter): ID da conta a ser limpa

**Exemplo Externo:**
```bash
curl -X POST "https://api.atria.ia.br/api/v1/enriquecimento/limpar-campos-vazios/418" \
     -H "x-api-key: 4c3c4f0333937787a316fd5240e0999ba17fc3e33646289f8d8b95b97b2c6a4e" \
     -H "Authorization: Bearer SEU_JWT_TOKEN"
```

**Resposta (200):**
```json
{
  "status": "ok",
  "conta_id": 418,
  "campos_limpos": 3
}
```

**Erros:**
- `403`: API Key inválida ou Token JWT inválido
- `404`: Conta não encontrada
- `500`: Erro interno do servidor

---

### 6. Enriquecer Contato com LinkedIn (NOVA FUNCIONALIDADE)
**Busca dados do LinkedIn para um contato específico via Apify**

- **Método**: `POST`
- **Rota Externa**: `https://api.atria.ia.br/api/v1/enriquecimento/contato/{contato_id}`
- **Rota Interna**: `http://127.0.0.1:8000/api/v1/enriquecimento/contato/{contato_id}`
- **Autenticação**: X-API-KEY + JWT Token

**Inputs:**
- `contato_id` (path parameter): ID do contato a ser enriquecido

**Exemplo Externo:**
```bash
curl -X POST "https://api.atria.ia.br/api/v1/enriquecimento/contato/586" \
     -H "x-api-key: 4c3c4f0333937787a316fd5240e0999ba17fc3e33646289f8d8b95b97b2c6a4e" \
     -H "Authorization: Bearer SEU_JWT_TOKEN"
```

**Resposta (200):**
```json
{
  "id": 586,
  "status": "atualizado",
  "seguidores": 1250,
  "conexoes": 500,
  "resumo": "Analista de Redes Sênior na Brava Energia",
  "url_foto_perfil": "https://media.licdn.com/dms/image/...",
  "recomendacoes": {
    "received": ["João Silva", "Maria Santos"],
    "given": ["Pedro Costa"]
  },
  "experiencias_total": 5,
  "certificacoes": [
    "Cisco Certified Network Associate (CCNA)",
    "CompTIA Security+"
  ]
}
```

**Erros:**
- `403`: API Key inválida ou Token JWT inválido
- `404`: Contato não encontrado ou sem LinkedIn cadastrado
- `500`: Erro interno do servidor ou na API Apify

---

### 7. Classificar Departamento do Contato (NOVA FUNCIONALIDADE)
**Classifica um contato em um departamento com base no cargo**

- **Método**: `POST`
- **Rota Externa**: `https://api.atria.ia.br/api/v1/enriquecimento/classificar-departamento/{contato_id}`
- **Rota Interna**: `http://127.0.0.1:8000/api/v1/enriquecimento/classificar-departamento/{contato_id}`
- **Autenticação**: X-API-KEY + JWT Token

**Inputs:**
- `contato_id` (path parameter): ID do contato a ser classificado

**Exemplo Externo:**
```bash
curl -X POST "https://api.atria.ia.br/api/v1/enriquecimento/classificar-departamento/586" \
     -H "x-api-key: 4c3c4f0333937787a316fd5240e0999ba17fc3e33646289f8d8b95b97b2c6a4e" \
     -H "Authorization: Bearer SEU_JWT_TOKEN"
```

**Resposta (200):**
```json
{
  "id": 586,
  "cargo": "Analista de Redes",
  "departamento_id": 1,
  "status": "classificado",
  "origem": "offline"
}
```

**Valores de origem:**
- `offline`: Encontrado no mapeamento existente
- `IA`: Classificado pela inteligência artificial
- `nao_encontrado`: Atribuído ao departamento padrão

**Erros:**
- `403`: API Key inválida ou Token JWT inválido
- `404`: Contato não encontrado
- `500`: Erro interno do servidor

---

## Códigos de Status HTTP

| Código | Significado | Quando Ocorre |
|--------|-------------|---------------|
| `200` | OK | Requisição processada com sucesso |
| `201` | Created | Recurso criado com sucesso |
| `400` | Bad Request | Dados inválidos ou regras de negócio violadas |
| `401` | Unauthorized | Token JWT inválido ou expirado |
| `403` | Forbidden | X-API-KEY inválida ou ausente |
| `404` | Not Found | Recurso não encontrado |
| `422` | Unprocessable Entity | Erro de validação nos dados |
| `500` | Internal Server Error | Erro interno do servidor |

---

## Validações e Regras de Negócio

### CNPJ
- **Formato**: Exatamente 14 dígitos numéricos
- **Limpeza**: Remove automaticamente pontos, barras e hífens
- **Unicidade**: Não permite CNPJs duplicados no sistema

### Site
- **Limpeza**: Remove automaticamente `http://`, `https://` e `www.`
- **Formato**: Armazena apenas o domínio limpo

### LinkedIn
- **Validação**: Deve conter "linkedin.com" na URL
- **Formato**: Aceita URLs completas do LinkedIn

### Email
- **Validação**: Formato de email válido
- **Unicidade**: Não permite emails duplicados no sistema

### Relacionamentos
- **Setor e Categoria**: IDs devem existir nas respectivas tabelas
- **Contatos Vinculados**: Não é possível deletar conta com contatos vinculados

---

## Funcionalidades Pendentes de Implementação

### Módulo Auxiliares (Crítico)
As seguintes rotas estão documentadas mas **não foram implementadas**:
- `GET /api/v1/auxiliares/setores`
- `GET /api/v1/auxiliares/categorias`
- `GET /api/v1/auxiliares/departamentos`

### Rota de Enriquecimento por Site
A rota `POST /api/v1/enriquecimento/site/{conta_id}` estava na documentação original mas não foi encontrada no código-fonte atual.

---

## Estrutura do Banco de Dados

### Tabela: contas
| Campo | Tipo | Descrição |
|-------|------|-----------|
| `id` | integer | Chave primária auto-incremento |
| `nome` | text | Nome da empresa (obrigatório) |
| `razao_social` | text | Razão social oficial |
| `cnpj` | varchar(18) | CNPJ da empresa (único) |
| `site` | text | Website da empresa |
| `linkedin` | text | URL do LinkedIn |
| `funcionarios` | integer | Número de funcionários |
| `estado` | text | Estado (UF) |
| `cidade` | text | Cidade |
| `endereco` | text | Endereço completo |
| `setor_id` | integer | FK para tabela setores |
| `categoria_id` | integer | FK para tabela categorias |
| `descricao` | text | Descrição da empresa |
| `tipo_estabelecimento` | text | Matriz/Filial |
| `capital_social` | numeric | Capital social |
| `descricao_oficial` | text | Descrição oficial da Receita |
| `numero_seguidores` | integer | Seguidores no LinkedIn |
| `logo_url` | text | URL do logo da empresa |
| `inconsistencias` | text[] | Array de inconsistências |
| `industria` | text | Indústria/setor de atuação |
| `especialidade` | text | Especialidades da empresa |
| `criado_em` | timestamp | Data de criação |
| `atualizado_em` | timestamp | Data da última atualização |
| `criado_por` | text | Email do usuário criador |

### Tabela: contatos
| Campo | Tipo | Descrição |
|-------|------|-----------|
| `id` | integer | Chave primária auto-incremento |
| `nome` | text | Nome do contato |
| `cargo` | text | Cargo/função |
| `nivel_hierarquico_id` | integer | FK para tabela nivel_hierarquico |
| `email` | varchar | Email do contato (único) |
| `telefone` | varchar | Telefone principal |
| `telefone2` | varchar | Telefone secundário |
| `linkedin` | varchar | Perfil do LinkedIn |
| `contato_whatsapp` | boolean | Se o telefone é WhatsApp |
| `tags` | varchar | Lista de tags |
| `observacoes` | text | Observações gerais |
| `empresa_id` | integer | FK para tabela contas |
| `departamento_id` | integer | FK para tabela departamento |
| `reporta_a` | integer | FK para contatos.id |
| `seguidores` | integer | Seguidores no LinkedIn |
| `conexoes` | integer | Conexões no LinkedIn |
| `resumo` | text | Headline do LinkedIn |
| `profile_url` | text | URL da foto de perfil |
| `recomendacoes` | jsonb | Recomendações (received/given) |
| `experiencias` | jsonb | Lista de experiências profissionais |
| `certificacoes` | jsonb | Lista de certificações |
| `created_at` | timestamp | Data de criação |
| `updated_at` | timestamp | Data de atualização |
| `atualizado_em` | timestamp | Última modificação |

---

## Notas Importantes

1. **Requisições Internas**: Chamadas feitas de `127.0.0.1` não precisam de X-API-KEY
2. **Rate Limiting**: Não implementado atualmente
3. **Versionamento**: Todas as rotas usam `/api/v1/` para versionamento
4. **CORS**: Configurado para aceitar qualquer origem (`*`)
5. **SSL**: Obrigatório para acesso externo (HTTPS)
6. **Timezone**: Configurado para America/Sao_Paulo
7. **Logs**: Sistema de logging implementado com timestamps e detalhes de requisição

---

## Exemplos de Uso Completo

### Fluxo Típico de Uso

1. **Fazer Login:**
```bash
TOKEN=$(curl -s -X POST "https://api.atria.ia.br/api/v1/auth/login" \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@atria.com","password":"admin123"}' \
  | jq -r '.access_token')
```

2. **Listar Contas:**
```bash
curl -X GET "https://api.atria.ia.br/api/v1/contas/?page=1&limit=10" \
  -H "x-api-key: 4c3c4f0333937787a316fd5240e0999ba17fc3e33646289f8d8b95b97b2c6a4e" \
  -H "Authorization: Bearer $TOKEN"
```

3. **Criar Nova Conta:**
```bash
curl -X POST "https://api.atria.ia.br/api/v1/contas/" \
  -H "x-api-key: 4c3c4f0333937787a316fd5240e0999ba17fc3e33646289f8d8b95b97b2c6a4e" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "nome": "Nova Empresa",
    "cnpj": "12345678000195",
    "setor_id": 1,
    "categoria_id": 2
  }'
```

4. **Enriquecer com CNPJ:**
```bash
curl -X POST "https://api.atria.ia.br/api/v1/enriquecimento/cnpj/418" \
  -H "x-api-key: 4c3c4f0333937787a316fd5240e0999ba17fc3e33646289f8d8b95b97b2c6a4e" \
  -H "Authorization: Bearer $TOKEN"
```

5. **Upload em Lote:**
```bash
curl -X POST "https://api.atria.ia.br/api/v1/contas/lote" \
  -H "x-api-key: 4c3c4f0333937787a316fd5240e0999ba17fc3e33646289f8d8b95b97b2c6a4e" \
  -H "Authorization: Bearer $TOKEN" \
  -F "arquivo=@empresas.csv"
```

---

**Documentação atualizada em:** 2 de outubro de 2025  
**Versão da API:** 1.0  
**Autor:** Manus AI
