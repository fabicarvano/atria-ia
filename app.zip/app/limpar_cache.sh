#!/bin/bash
# Script para limpar todos os caches da API

echo "🧹 Iniciando limpeza de cache..."

# 1. Limpar cache Python
echo "🐍 Limpando cache Python..."
find /atria.ia.br/app -name "*.pyc" -delete
find /atria.ia.br/app -name "__pycache__" -type d -exec rm -rf {} + 2>/dev/null

# 2. Limpar cache do sistema
echo "💾 Limpando cache do sistema..."
sync
echo 3 > /proc/sys/vm/drop_caches

# 3. Limpar cache NGINX (se existir)
echo "🌐 Limpando cache NGINX..."
rm -rf /var/cache/nginx/* 2>/dev/null
nginx -s reload 2>/dev/null

# 4. Reiniciar aplicação
echo "🔄 Reiniciando aplicação..."
pm2 restart atria-backend

echo "✅ Limpeza concluída!"
echo "📋 Acesse: https://api.atria.ia.br/docs"
