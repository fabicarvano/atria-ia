module.exports = {
  apps: [
    {
      name: "atria-backend",
      cwd: "/atria.ia.br/app",
      script: "venv/bin/uvicorn",                   // uvicorn dentro do venv
      args: "main:app --host 0.0.0.0 --port 8000",  // main:app como argumento
      interpreter: "none",                          // não deixar PM2 usar node/python
      autorestart: true,
      watch: false,
      env: {
        PYTHONPATH: "/atria.ia.br/app"              // garante que 'servicos' seja visto
      }
    },
    {
      name: "escuta-contas",
      cwd: "/atria.ia.br/app/scripts",
      script: "../venv/bin/python3",                // python3 dentro do venv
      args: "escuta_contas.py",                     // script de escuta
      interpreter: "none",                          // não deixar PM2 usar node/python
      autorestart: true,
      watch: false,
      env: {
        PYTHONPATH: "/atria.ia.br/app",             // garante visibilidade do projeto
        DB_HOST: "85.25.172.43",
        DB_PORT: "5433",
        DB_NAME: "atria",
        DB_USER: "backend_user",
        DB_PASS: "5r4vBHq.BUu9*A#t^y6"
      }
    }
  ]
}
