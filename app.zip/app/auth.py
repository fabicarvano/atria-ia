from fastapi import APIRouter, HTTPException, Depends, status
from pydantic import BaseModel, EmailStr
from jose import jwt, JWTError
from passlib.context import CryptContext
from datetime import datetime, timedelta, timezone
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from database import get_conn

router = APIRouter(prefix="/api/v1/auth", tags=["auth"])

# Configurações
SECRET_KEY = "troque_essa_chave_para_uma_muito_forte"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 5256000

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
security = HTTPBearer()

# Schemas
class LoginIn(BaseModel):
    email: EmailStr
    password: str

class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"

class UserOut(BaseModel):
    id: int
    nome: str
    email: EmailStr
    role: str
    is_active: bool

# Funções utilitárias
def create_access_token(data: dict, expires_delta: timedelta | None = None):
    to_encode = data.copy()
    expire = datetime.now(timezone.utc) + (expires_delta or timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES))
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)

def get_user_by_email(email: str):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT * FROM usuarios WHERE email = %s", (email,))
    user = cur.fetchone()
    conn.close()
    return user

def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)):
    token = credentials.credentials
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        user_id = int(payload.get("sub"))
    except JWTError:
        raise HTTPException(status_code=401, detail="Token inválido")

    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT * FROM usuarios WHERE id = %s", (user_id,))
    user = cur.fetchone()
    conn.close()
    if not user:
        raise HTTPException(status_code=401, detail="Usuário não encontrado")
    return user

# Rota de login (sem exigir x-api-key)
@router.post("/login", response_model=TokenOut, tags=["auth"])
def login(data: LoginIn):
    # Busca o usuário pelo e-mail
    user = get_user_by_email(data.email)

    # Valida se o usuário existe e a senha está correta
    if not user or not pwd_context.verify(data.password, user["senha_hash"]):
        raise HTTPException(
            status_code=401,
            detail="Credenciais inválidas"
        )

    # Dados que vão dentro do token JWT
    token_data = {
        "sub": str(user["id"]),
        "role": user["role"],
        "is_active": user.get("is_active", True)
    }

    # Cria o JWT com tempo de expiração definido
    access_token = create_access_token(data=token_data)

    return {
        "access_token": access_token,
        "token_type": "bearer"
    }

# Rota me
@router.get("/me", response_model=UserOut)
def me(current_user: dict = Depends(get_current_user)):
    return current_user
