#!/usr/bin/env python3
import os
import psycopg2
import requests
from dotenv import load_dotenv

# 🔑 Carregar variáveis do .env
load_dotenv("/atria.ia.br/app/.env")
API_KEY = os.getenv("ATRIA_API_KEY")
BEARER = os.getenv("BEARER_SERVICE")

DB_HOST = os.getenv("DB_HOST")
DB_NAME = os.getenv("DB_NAME")
DB_USER = os.getenv("DB_USER")
DB_PASS = os.getenv("DB_PASS")
DB_PORT = os.getenv("DB_PORT", "5432")  # default 5432

BASE_URL = "http://127.0.0.1:8000/api/v1/enriquecimento/contatos/validar/linkedin-vazio"

# ---------------------------
# Buscar IDs de contatos
# ---------------------------
def get_all_contatos():
    conn = psycopg2.connect(
        host=DB_HOST,
        dbname=DB_NAME,
        user=DB_USER,
        password=DB_PASS,
        port=DB_PORT
    )
    cur = conn.cursor()
    cur.execute("SELECT id FROM contatos ORDER BY id")
    ids = [row[0] for row in cur.fetchall()]
    cur.close()
    conn.close()
    return ids

# ---------------------------
# Validar LinkedIn por rota
# ---------------------------
def validar_linkedin(contato_id):
    url = f"{BASE_URL}/{contato_id}"
    headers = {
        "x-api-key": API_KEY,
        "Authorization": f"Bearer {BEARER}"
    }
    try:
        resp = requests.post(url, headers=headers, timeout=20)
        return resp.status_code, resp.json()
    except Exception as e:
        return 500, {"erro": str(e)}

# ---------------------------
# Execução principal
# ---------------------------
if __name__ == "__main__":
    contatos = get_all_contatos()
    total = len(contatos)
    print(f"🔎 Validando LinkedIn de {total} contatos...")

    for i, contato_id in enumerate(contatos, start=1):
        status, data = validar_linkedin(contato_id)
        print(f"[{i}/{total}] Contato {contato_id} -> {status} {data}")
