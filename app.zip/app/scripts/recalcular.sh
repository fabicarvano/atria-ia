#!/bin/bash

# Carregar variáveis do .env
set -a
source .env
set +a

# Verifica dependências
command -v psql >/dev/null 2>&1 || { echo "❌ psql não encontrado. Instale o cliente PostgreSQL."; exit 1; }
command -v jq >/dev/null 2>&1 || { echo "⚠️ jq não encontrado. Instale com: apt install jq -y"; }

# Buscar todos os IDs de contas no banco
EMPRESAS=$(psql "$DATABASE_URL" -t -c "SELECT id FROM contas ORDER BY id;")

# Loop pelas empresas
for EMPRESA_ID in $EMPRESAS; do
  echo "🔄 Recalculando hierarquia para empresa $EMPRESA_ID..."
  RESPONSE=$(curl -s -X POST "http://127.0.0.1:8000/api/v1/contatos/hierarquia/recalcular/$EMPRESA_ID" \
    -H "Authorization: Bearer $BEARER_SERVICE")
  
  # Se tiver jq, formata, senão mostra direto
  if command -v jq >/dev/null 2>&1; then
    echo "$RESPONSE" | jq .
  else
    echo "$RESPONSE"
  fi
  echo "---------------------------------------------"
done

echo "✅ Recalculo de hierarquia concluído para todas as contas."
