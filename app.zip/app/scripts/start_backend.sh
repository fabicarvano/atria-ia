#!/bin/bash

# Ativar o ambiente virtual
source /atria.ia.br/app/venv/bin/activate

# Navegar até o diretório do projeto
cd /atria.ia.br/app

# Iniciar o backend com PM2
pm2 start "uvicorn main:app --host 0.0.0.0 --port 8000" --name "atria-backend"

# Salvar a configuração para iniciar no boot
pm2 save
