#!/usr/bin/env python3
import sys
import os
import requests
import urllib3
import psycopg2
from datetime import datetime
from dotenv import load_dotenv

# Evita warnings se usar verify=False
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Carregar variáveis do .env
load_dotenv()

# ========================
# 🔹 Configurações
# ========================
API_BASE = "http://127.0.0.1:8000/api/v1/enriquecimento"  # Rota interna FastAPI
BEARER_SERVICE = os.getenv("BEARER_SERVICE")

if not BEARER_SERVICE:
    print("❌ ERRO: BEARER_SERVICE não encontrado no arquivo .env")
    sys.exit(1)

HEADERS = {
    "Authorization": f"Bearer {BEARER_SERVICE}",
    "Content-Type": "application/json"
}

def log_info(mensagem):
    """Log com timestamp para controle"""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    print(f"[{timestamp}] {mensagem}")

def chamar_rota(nome, url, metodo="POST", payload=None):
    """Chama uma rota da API com tratamento de erro e logs detalhados"""
    try:
        log_info(f"🔄 Iniciando {nome}...")
        
        if metodo == "POST":
            r = requests.post(url, headers=HEADERS, json=payload, timeout=180, verify=False)
        else:
            r = requests.get(url, headers=HEADERS, timeout=180, verify=False)

        if r.status_code in (200, 201):
            log_info(f"✅ {nome}: Sucesso ({r.status_code})")
            
            # Exibir dados específicos por rota
            try:
                data = r.json()
                
                if nome == "CNPJ":
                    razao = data.get("razao_social", "N/A")
                    cidade = data.get("cidade", "N/A")
                    tipo = data.get("tipo_estabelecimento", "N/A")
                    email = data.get("email", "N/A")
                    log_info(f"   📋 Razão Social: {razao}")
                    log_info(f"   📍 Cidade: {cidade} | Tipo: {tipo}")
                    log_info(f"   📧 Email: {email}")
                
                elif nome == "LinkedIn":
                    if data.get("message"):
                        log_info(f"   ⚠️ {data.get('message')}")
                    else:
                        empresa = data.get("empresa_principal", {})
                        funcionarios = empresa.get("funcionarios", "N/A")
                        industria = empresa.get("industria", "N/A")
                        site = empresa.get("site", "N/A")
                        similares = data.get("similares_inseridas", 0)
                        log_info(f"   👥 Funcionários: {funcionarios}")
                        log_info(f"   🏭 Indústria: {industria}")
                        log_info(f"   🌐 Site: {site}")
                        log_info(f"   🔗 Empresas similares inseridas: {similares}")
                
                elif nome == "Padronizar Setores":
                    setor_id = data.get("setor_id", "N/A")
                    nome_setor = data.get("nome_setor", "N/A")
                    criado = data.get("mapeamento_criado", False)
                    fonte = data.get("fonte", "N/A")
                    log_info(f"   🎯 Setor: {nome_setor} (ID: {setor_id})")
                    log_info(f"   🤖 Fonte: {fonte} | Mapeamento criado: {criado}")
                
                elif nome == "Validação":
                    inconsistencias = data.get("inconsistencias", [])
                    if inconsistencias:
                        log_info(f"   ⚠️ Inconsistências: {', '.join(inconsistencias)}")
                    else:
                        log_info("   ✅ Nenhuma inconsistência encontrada")


                    
            except Exception as e:
                log_info(f"   ⚠️ Erro ao processar resposta: {e}")
            
            return True
        else:
            log_info(f"❌ {nome}: Erro {r.status_code}")
            log_info(f"   📝 Detalhes: {r.text[:300]}")
            return False
            
    except Exception as e:
        log_info(f"⚠️ {nome}: Exceção - {e}")
        return False

def padronizar_setores_empresa(conta_id):
    """Executa a padronização de setores chamando a rota do backend"""
    try:
        DATABASE_URL = os.getenv("DATABASE_URL")
        conn = psycopg2.connect(DATABASE_URL)
        cur = conn.cursor()

        cur.execute("SELECT industria FROM contas WHERE id = %s", (conta_id,))
        row = cur.fetchone()

        cur.close()
        conn.close()

        if not row:
            log_info("❌ Conta não encontrada no banco")
            return False

        industria = row[0] if row[0] and row[0].strip() != "" else "Industria não cadastrada"

        if industria == "Industria não cadastrada":
            log_info("⚠️ Indústria não informada no banco, enviando 'Industria não cadastrada' para padronização")

        payload = {"nome_industria": industria}
        url_setor = f"{API_BASE}/padronizar-setor"

        return chamar_rota("Padronizar Setores", url_setor, metodo="POST", payload=payload)

    except Exception as e:
        log_info(f"❌ Erro na padronização de setores: {e}")
        return False

def main():
    """Função principal do script de enriquecimento"""
    if len(sys.argv) < 2:
        print("❌ Uso: python3 enriquecimento_automatico_final.py <conta_id>")
        sys.exit(1)

    try:
        conta_id = int(sys.argv[1])
    except ValueError:
        print("❌ ERRO: conta_id deve ser um número inteiro")
        sys.exit(1)

    log_info("=" * 70)
    log_info(f"🚀 INICIANDO ENRIQUECIMENTO AUTOMÁTICO - CONTA ID: {conta_id}")
    log_info("=" * 70)

    sucesso_total = True
    etapas_executadas = 0
    total_etapas = 4

    # 1. CNPJ - Dados oficiais da empresa + email
    log_info(f"📋 ETAPA 1/{total_etapas}: Enriquecimento por CNPJ")
    url_cnpj = f"{API_BASE}/cnpj/{conta_id}"
    if chamar_rota("CNPJ", url_cnpj):
        etapas_executadas += 1
    else:
        sucesso_total = False
        log_info("⚠️ Continuando mesmo com erro no CNPJ...")

    # 2. LinkedIn - Dados do LinkedIn + empresas similares + site
    log_info(f"🔗 ETAPA 2/{total_etapas}: Enriquecimento por LinkedIn")
    url_linkedin = f"{API_BASE}/linkedin/{conta_id}"
    if chamar_rota("LinkedIn", url_linkedin):
        etapas_executadas += 1
    else:
        sucesso_total = False
        log_info("⚠️ Continuando mesmo com erro no LinkedIn...")

    # 3. Padronizar Setores - Mapear indústrias para setores (placeholder)
    log_info(f"🎯 ETAPA 3/{total_etapas}: Padronização de Setores")
    if padronizar_setores_empresa(conta_id):
        etapas_executadas += 1
    else:
        sucesso_total = False
        log_info("⚠️ Continuando mesmo com erro na Padronização...")

    # 4. Validação Final - Verificar inconsistências (OTIMIZADA)
    log_info(f"🔍 ETAPA 4/{total_etapas}: Validação de Inconsistências")
    url_validacao = f"{API_BASE}/validar-inconsistencias/{conta_id}"
    if chamar_rota("Validação", url_validacao):
        etapas_executadas += 1
    else:
        sucesso_total = False

    # Resumo final
    log_info("=" * 70)
    log_info(f"📊 RESUMO DO ENRIQUECIMENTO - CONTA ID: {conta_id}")
    log_info(f"✅ Etapas executadas com sucesso: {etapas_executadas}/{total_etapas}")
    
    if sucesso_total:
        log_info("🎉 ENRIQUECIMENTO CONCLUÍDO COM SUCESSO!")
        sys.exit(0)
    else:
        log_info("⚠️ ENRIQUECIMENTO CONCLUÍDO COM ALGUNS ERROS")
        sys.exit(1)

if __name__ == "__main__":
    main()
