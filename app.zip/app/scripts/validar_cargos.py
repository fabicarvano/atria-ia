import os
import psycopg2
import requests
from dotenv import load_dotenv

# ---------------------------
# Carregar variáveis de ambiente
# ---------------------------
load_dotenv("/atria.ia.br/app/.env")

API_KEY = os.getenv("ATRIA_API_KEY")
BEARER = os.getenv("BEARER_SERVICE")

DB_HOST = os.getenv("DB_HOST")
DB_PORT = os.getenv("DB_PORT", "5432")
DB_NAME = os.getenv("DB_NAME")
DB_USER = os.getenv("DB_USER")
DB_PASS = os.getenv("DB_PASS")

BASE_URL = os.getenv("ATRIA_API_URL", "http://127.0.0.1:8000")
ROTA = "/api/v1/enriquecimento/contatos/validar/cargo-vazio"

# ---------------------------
# Conectar no banco e pegar IDs de contatos
# ---------------------------
def get_contato_ids():
    conn = psycopg2.connect(
        host=DB_HOST,
        port=DB_PORT,
        dbname=DB_NAME,
        user=DB_USER,
        password=DB_PASS
    )
    cur = conn.cursor()
    cur.execute("SELECT id FROM contatos ORDER BY id;")
    ids = [row[0] for row in cur.fetchall()]
    cur.close()
    conn.close()
    return ids

# ---------------------------
# Chamar rota de validação
# ---------------------------
def validar_cargo(contato_id: int):
    url = f"{BASE_URL}{ROTA}/{contato_id}"
    headers = {
        "x-api-key": API_KEY,
        "Authorization": f"Bearer {BEARER}"
    }
    try:
        r = requests.post(url, headers=headers, timeout=10)
        try:
            return r.status_code, r.json()
        except Exception:
            return r.status_code, {"raw_response": r.text}
    except Exception as e:
        return 500, {"erro": str(e)}

# ---------------------------
# Main
# ---------------------------
if __name__ == "__main__":
    ids = get_contato_ids()
    print(f"🔎 Total de contatos encontrados: {len(ids)}")

    for i, cid in enumerate(ids, 1):
        status, resp = validar_cargo(cid)
        print(f"[{i}/{len(ids)}] Contato {cid} -> {status} {resp}")
