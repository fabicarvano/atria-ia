#!/bin/bash

# Carrega variáveis do .env
set -a
source /atria.ia.br/app/.env
set +a

# URL da API (rota correta)
BASE_URL="$ATRIA_BASE_URL/api/v1/enriquecimento/classificar-departamento"

# Token direto do .env
TOKEN=$BEARER_SERVICE

# Buscar todos os IDs da tabela contatos
IDS=$(psql "$DATABASE_URL" -t -A -c "SELECT id FROM contatos ORDER BY id;")

echo "🔎 Iniciando classificação de departamentos para $(echo $IDS | wc -w) contatos..."

for ID in $IDS; do
  echo "➡️  Processando contato ID: $ID"

  RESPONSE=$(curl -s -o /dev/null -w "%{http_code}" -X POST \
    "$BASE_URL/$ID" \
    -H "Authorization: Bearer $TOKEN" \
    -H "Content-Type: application/json")

  if [ "$RESPONSE" -eq 200 ]; then
    echo "✅ Contato $ID classificado com sucesso."
  else
    echo "❌ Falha ao classificar contato $ID (HTTP $RESPONSE)."
  fi
done

echo "🏁 Finalizado."
