import os
import requests
from dotenv import load_dotenv

# Carregar variáveis do .env
load_dotenv()

API_BASE = os.getenv("API_BASE", "http://127.0.0.1:8000/api/v1")
BEARER = os.getenv("BEARER_SERVICE")
API_KEY = os.getenv("ATRIA_API_KEY")

HEADERS = {
    "Authorization": f"Bearer {BEARER}",
    "x-api-key": API_KEY
}

# IDs de contatos com LinkedIn cadastrado
CONTATOS = [
    7, 19, 29, 32, 33, 51, 55, 63, 70, 77, 90, 100, 102, 117, 131,
    134, 143, 149, 163, 170, 182, 184, 199, 214, 225, 237, 239, 249,
    511, 789, 798, 801
]

def enriquecer_contato(contato_id: int):
    url = f"{API_BASE}/enriquecimento/contato/{contato_id}"
    try:
        r = requests.post(url, headers=HEADERS, timeout=60)
        if r.status_code == 200:
            print(f"[{contato_id}] OK -> {r.json()}")
        else:
            print(f"[{contato_id}] ERRO {r.status_code} -> {r.text}")
    except Exception as e:
        print(f"[{contato_id}] Falha na requisição: {e}")

if __name__ == "__main__":
    for idx, contato_id in enumerate(CONTATOS, start=1):
        print(f"({idx}/{len(CONTATOS)}) Enriquecendo contato {contato_id}...")
        enriquecer_contato(contato_id)
