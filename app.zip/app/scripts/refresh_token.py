import os
import requests
from dotenv import load_dotenv

# Carregar variáveis do .env
load_dotenv()

API_URL = os.getenv("API_URL", "https://api.atria.com/api/v1/auth/login")
ADMINUSER = os.getenv("ADMINUSER")
ADMINPASS = os.getenv("ADMINPASS")
ENV_FILE = "/atria.ia.br/app/.env"

def refresh_token():
    # Faz login
    response = requests.post(API_URL, json={
        "email": ADMINUSER,
        "password": ADMINPASS
    })

    if response.status_code != 200:
        print("Erro ao obter token:", response.text)
        return

    token = response.json().get("access_token")

    if not token:
        print("Nenhum token retornado!")
        return

    print("Novo token obtido:", token[:30] + "...")

    # Lê .env existente
    lines = []
    with open(ENV_FILE, "r") as f:
        lines = f.readlines()

    # Atualiza BEARER_SERVICE ou cria se não existir
    found = False
    for i, line in enumerate(lines):
        if line.startswith("BEARER_SERVICE="):
            lines[i] = f"BEARER_SERVICE={token}\n"
            found = True
            break
    if not found:
        lines.append(f"BEARER_SERVICE={token}\n")

    # Escreve de volta
    with open(ENV_FILE, "w") as f:
        f.writelines(lines)

    print("Arquivo .env atualizado com novo token.")

if __name__ == "__main__":
    refresh_token()
