#!/usr/bin/env python3
import psycopg2
import select
import subprocess
import sys
import os
from datetime import datetime
from dotenv import load_dotenv

# ========================
# 🔹 Configurações do Banco de Dados
# ========================
# Carrega variáveis do .env
load_dotenv(dotenv_path="/atria.ia.br/app/.env")

DB_CONFIG = {
    "dbname": os.getenv("DB_NAME"),
    "user": os.getenv("DB_USER"),
    "password": os.getenv("DB_PASS"),
    "host": os.getenv("DB_HOST"),
    "port": os.getenv("DB_PORT"),
}

CANAL = "contas_channel"

def log(msg):
    """Escreve logs formatados para o PM2"""
    sys.stdout.write(f"[{datetime.now()}] {msg}\n")
    sys.stdout.flush()

def main():
    try:
        conn = psycopg2.connect(**DB_CONFIG)
        conn.set_isolation_level(psycopg2.extensions.ISOLATION_LEVEL_AUTOCOMMIT)
        cur = conn.cursor()
        cur.execute(f"LISTEN {CANAL};")
        log(f"🚀 Worker iniciado e conectado ao banco {DB_CONFIG['dbname']}:{DB_CONFIG['port']} (canal={CANAL})")
        log("⏳ Aguardando notificações...")
    except Exception as e:
        log(f"❌ Erro ao conectar ao banco: {e}")
        sys.exit(1)

    while True:
        if select.select([conn], [], [], 5) == ([], [], []):
            continue
        conn.poll()
        while conn.notifies:
            notify = conn.notifies.pop(0)
            payload = notify.payload.strip()
            log(f"🔔 Notificação recebida no canal {CANAL}: payload={payload}")

            try:
                conta_id = int(payload)
                log(f"➡️ Iniciando contas.py para ID={conta_id}")
                subprocess.run(
                    ["python3", "/atria.ia.br/app/scripts/contas.py", str(conta_id)],
                    check=True
                )
                log(f"✅ contas.py finalizado com sucesso para ID={conta_id}")
            except Exception as e:
                log(f"❌ Erro ao executar contas.py ID={payload}: {e}")
       
            # Mensagem de retorno para estado de espera
            log("⏳ Aguardando notificações...")

if __name__ == "__main__":
    main()
