# /atria.ia.br/app/scripts/classificar_todas_empresas.py
import os
import psycopg2
from dotenv import load_dotenv
from servicos.hierarquia_contatos import classificar_nivel

# Carregar variáveis de ambiente
load_dotenv("/atria.ia.br/app/.env")

DB_HOST = os.getenv("DB_HOST")
DB_PORT = os.getenv("DB_PORT", "5432")
DB_NAME = os.getenv("DB_NAME")
DB_USER = os.getenv("DB_USER")
DB_PASSWORD = os.getenv("DB_PASS")

def get_connection():
    return psycopg2.connect(
        host=DB_HOST,
        port=DB_PORT,
        dbname=DB_NAME,
        user=DB_USER,
        password=DB_PASSWORD
    )

def classificar_todas():
    conn = get_connection()
    cur = conn.cursor()

    # Buscar todas as empresas que têm contatos
    cur.execute("SELECT DISTINCT empresa_id FROM contatos WHERE empresa_id IS NOT NULL")
    empresas = cur.fetchall()

    total_empresas = 0
    total_contatos = 0

    for (empresa_id,) in empresas:
        cur.execute("SELECT id, cargo FROM contatos WHERE empresa_id = %s", (empresa_id,))
        contatos = cur.fetchall()

        atualizados = 0
        for contato_id, cargo in contatos:
            nivel_id = classificar_nivel(cargo)
            cur.execute(
                "UPDATE contatos SET nivel_hierarquico_id = %s WHERE id = %s",
                (nivel_id, contato_id)
            )
            atualizados += 1
            total_contatos += 1

        if atualizados > 0:
            print(f"✅ Empresa {empresa_id}: {atualizados} contatos classificados")
            total_empresas += 1

    conn.commit()
    cur.close()
    conn.close()

    print(f"\n🎯 Finalizado! {total_contatos} contatos atualizados em {total_empresas} empresas.")

if __name__ == "__main__":
    classificar_todas()
