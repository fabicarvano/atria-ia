# Atria IA Backend

Backend desenvolvido em **FastAPI** para o sistema **Atria**, responsável pela autenticação, gerenciamento de contas, contatos e enriquecimento de dados via LinkedIn/Apify e OpenAI.

---

## 📂 Estrutura do Projeto

```
app/
├── auth.py                  # Autenticação e JWT
├── contas.py                # Rotas de contas
├── contatos.py              # Rotas de contatos
├── database.py              # Conexão com PostgreSQL
├── main.py                  # Entrada principal FastAPI
├── servicos/                # Serviços auxiliares
│   ├── enriquecimento.py
│   ├── enriquecimento_contato.py
├── scripts/                 # Scripts auxiliares
│   ├── contas.py
│   ├── escuta_contas.py
│   ├── refresh_token.py
├── ecosystem.config.js      # Configuração do PM2
├── requirements.txt         # Dependências
└── docs/                    # Documentação
    ├── documentaca_dev
    └── documentacao_API
```

---

## ⚙️ Configuração do Ambiente

### 1. Clonar o repositório
```bash
git clone git@github.com:fabicarvano/atria.ia.git
cd atria.ia/app
```

### 2. Criar ambiente virtual
```bash
python3 -m venv venv
source venv/bin/activate
```

### 3. Instalar dependências
```bash
pip install -r requirements.txt
```

### 4. Configurar variáveis de ambiente
Crie um arquivo `.env` na raiz (`/atria.ia.br/app/.env`) com:

```env
# Banco de dados
DB_HOST=localhost
DB_PORT=5432
DB_NAME=atria
DB_USER=postgres
DB_PASS=senha

# Segurança
ATRIA_API_KEY=sua_chave_api
JWT_SECRET=seu_jwt_secret
JWT_ALGORITHM=HS256
ACCESS_TOKEN_EXPIRE_MINUTES=60

# Integrações externas
OPENAI_API_KEY=sua_openai_key
APIFY_LINKEDIN_COMPANY_KEY=sua_apify_key
```

---

## ▶️ Execução do Servidor

### Modo Dev
```bash
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

### Produção com PM2
```bash
pm2 start ecosystem.config.js
pm2 save
pm2 startup
```

---

## 🔑 Segurança

- Autenticação via **JWT** (Bearer Token)  
- Header obrigatório **X-API-KEY** para chamadas externas  
- IPs internos (`127.0.0.1`) liberados sem chave para automações  

---

## 📌 Endpoints Principais

- **Auth**
  - `POST /api/v1/auth/login` → Login com JWT
- **Contas**
  - `GET /api/v1/contas` → Listar contas
  - `POST /api/v1/contas` → Criar conta
- **Contatos**
  - `GET /api/v1/contatos` → Listar contatos
  - `POST /api/v1/contatos` → Criar contato
- **Enriquecimento**
  - `POST /api/v1/enriquecimento/padronizar-setor` → Padronizar setor de indústria
  - `POST /api/v1/enriquecimento/cnpj/{id}` → Enriquecer dados via CNPJ
  - `POST /api/v1/enriquecimento/linkedin/{id}` → Enriquecer via LinkedIn
  - `POST /api/v1/enriquecimento/validar-inconsistencias/{id}` → Validar inconsistências

---

## 🧩 Scripts Úteis

- `scripts/contas.py` → Atualizações de contas  
- `scripts/escuta_contas.py` → Listener de notificações PostgreSQL  
- `scripts/refresh_token.py` → Renovação de tokens externos  
- `start_backend.sh` → Inicialização simplificada  

---

## 🛠 Manutenção

- Logs do PM2 ficam em `/root/.pm2/logs/atria-backend-out.log`  
- Limpar cache temporário:  
  ```bash
  ./limpar_cache.sh
  ```

---

## 📄 Documentação

- **Docs internos**: `docs/documentaca_dev`  
- **API Swagger**: disponível em `/docs` após iniciar o backend  

---

## 📌 Roadmap

- [ ] Incrementar documentação do **Frontend**  
- [ ] Criar testes unitários automatizados  
- [ ] Melhorar auditoria e logs  
- [ ] CI/CD com GitHub Actions  
