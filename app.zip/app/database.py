# database.py
import os
import psycopg2
from psycopg2.extras import RealDictCursor
from dotenv import load_dotenv

# Carrega variáveis do .env
load_dotenv(dotenv_path="/atria.ia.br/app/.env")

def get_conn():
    """
    Cria e retorna uma conexão com o banco PostgreSQL
    usando as credenciais do .env
    """
    try:
        dsn = os.getenv("DATABASE_URL")
        if not dsn:
            raise ValueError("❌ Variável DATABASE_URL não encontrada no .env")

        conn = psycopg2.connect(dsn, cursor_factory=RealDictCursor)
        return conn
    except Exception as e:
        raise RuntimeError(f"Erro ao conectar ao banco: {e}")
