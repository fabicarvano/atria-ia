# /atria.ia.br/app/main.py
import os
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from fastapi.openapi.utils import get_openapi
from dotenv import load_dotenv

# Imports para logging
import logging
import time
from starlette.middleware.base import BaseHTTPMiddleware

# Imports dos módulos 
from auth import router as auth_router
from servicos import enriquecimento
from contas import router as contas_router
from contatos import router as contatos_router
from servicos import enriquecimento_contato, hierarquia_contatos_router
from servicos import analises_contas_router
from servicos import ranking_relacionamento_router 

## Garantir timezone corret0
import  time
os.environ['TZ'] = 'America/Sao_Paulo'
time.tzset()


# Configuração do logging
logging.basicConfig(
    level=logging.INFO,
    format='[%(asctime)s] %(levelname)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger("atria_api")

# Middleware de log
class RequestLogMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        start_time = time.time()
        response = await call_next(request)
        process_time = time.time() - start_time
        
        logger.info(
            f"{request.client.host} - {request.method} {request.url.path} - "
            f"Status: {response.status_code} - {process_time:.3f}s"
        )
        
        return response

# Carregar variáveis de ambiente
load_dotenv(dotenv_path="/atria.ia.br/app/.env")

# Criar aplicação FastAPI
app = FastAPI(title="Atria API")

# Configuração OpenAPI customizada
def custom_openapi():
    # ✅ SEMPRE recriar schema - nunca usar cache
    import time
    
    openapi_schema = get_openapi(
        title="Atria API",
        version=f"1.0.{int(time.time())}",  # ← Versão única baseada em timestamp
        description="API da Atria com autenticação X-API-KEY + JWT",
        routes=app.routes,
    )
    
    # Configuração de segurança
    openapi_schema["components"]["securitySchemes"] = {
        "ApiKeyAuth": {
            "type": "apiKey",
            "in": "header",
            "name": "x-api-key"
        },
        "BearerAuth": {
            "type": "http",
            "scheme": "bearer",
            "bearerFormat": "JWT"
        }
    }
    
    # Aplicar segurança globalmente
    for path in openapi_schema["paths"]:
        for method in openapi_schema["paths"][path]:
            if path != "/api/v1/auth/login":
                openapi_schema["paths"][path][method]["security"] = [
                    {"ApiKeyAuth": []},
                    {"BearerAuth": []}
                ]
    
    # ✅ NÃO salvar em cache - comentar esta linha:
    # app.openapi_schema = openapi_schema
    
    return openapi_schema
# API Key do ambiente
API_KEY = os.getenv("ATRIA_API_KEY")

# Registrar middleware de log
app.add_middleware(RequestLogMiddleware)

@app.middleware("http")
async def enforce_api_key(request: Request, call_next):
    # Obter IP real considerando NGINX
    real_ip = request.headers.get("X-Real-IP") or request.client.host

    # ✅ Liberar localhost (127.0.0.1 ou localhost) para QUALQUER rota exceto docs
    if real_ip in ["127.0.0.1", "localhost"] and not request.url.path.startswith("/docs"):
        return await call_next(request)

    # Documentação já protegida pelo NGINX
    if request.url.path in ["/docs", "/openapi.json"]:
        return await call_next(request)

    # Login sem chave
    if request.url.path == "/api/v1/auth/login":
        return await call_next(request)

    # 🔒 Validar X-API-KEY para todas as outras rotas externas
    if request.url.path.startswith("/api/"):
        client_key = request.headers.get("x-api-key")
        if not API_KEY or client_key != API_KEY:
            return JSONResponse(status_code=403, content={"detail": "API Key inválida ou ausente"})

    return await call_next(request)

# Registrar rotas (SEM contas e contatos)
app.include_router(auth_router)
app.include_router(enriquecimento.router, prefix="/api/v1/enriquecimento", tags=["enriquecimento"])
app.include_router(contas_router, prefix="/api/v1/contas", tags=["contas"])
app.include_router(contatos_router, prefix="/api/v1/contatos", tags=["contatos"])
app.include_router(enriquecimento_contato.router, prefix="/api/v1/enriquecimento", tags=["enriquecimento"])
app.include_router(hierarquia_contatos_router, prefix="/api/v1/contatos/hierarquia", tags=["hierarquia"])
app.include_router(analises_contas_router, prefix="/api/v1/analises", tags=["analises_contas"])
app.include_router(ranking_relacionamento_router, prefix="/api/v1/analises", tags=["ranking_relacionamento"])


@app.get("/api/v1/health")
def health():
    return {"status": "ok"}

# Configuração CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
