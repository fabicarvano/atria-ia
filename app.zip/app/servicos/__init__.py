from .enriquecimento import router as enriquecimento_router
from .enriquecimento_contato import router as enriquecimento_contato_router
from .hierarquia_contatos import router as hierarquia_contatos_router
from .analises_contas import router as analises_contas_router
from .ranking_relacionamento import router as ranking_relacionamento_router 
