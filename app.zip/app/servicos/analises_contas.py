import logging
from fastapi import APIRouter, HTTPException
from database import get_conn

router = APIRouter(tags=["analises_contas"])
logger = logging.getLogger(__name__)

# Função padrão Tulipa
def resposta_tulipa(status_: str, mensagem: str, dados):
    return {"status": status_, "mensagem": mensagem, "total": len(dados), "dados": dados}

SQL_BASE = """
SELECT 
    c.id AS conta_id,
    c.nome,
    COUNT(ct.id) AS total_contatos,
    SUM(CASE WHEN n.nome = 'C-Level' THEN 1 ELSE 0 END) AS c_level,
    SUM(CASE WHEN n.nome = 'Diretor' THEN 1 ELSE 0 END) AS diretores,
    SUM(CASE WHEN n.nome = 'Gestor' THEN 1 ELSE 0 END) AS gestores,
    SUM(CASE WHEN n.nome = 'Coordenador' THEN 1 ELSE 0 END) AS coordenadores,
    SUM(CASE WHEN n.nome = 'Analista' THEN 1 ELSE 0 END) AS analistas,
    SUM(CASE WHEN n.nome = 'Outro' THEN 1 ELSE 0 END) AS outros
FROM contas c
LEFT JOIN contatos ct ON c.id = ct.empresa_id
LEFT JOIN nivel_hierarquico n ON ct.nivel_hierarquico_id = n.id
GROUP BY c.id, c.nome
"""

# 1️⃣ Baixa decisão
@router.get("/baixa_decisao")
def analise_baixa_decisao():
    query = f"""
    WITH analise AS ({SQL_BASE})
    SELECT *, 
           ROUND((COALESCE(analistas,0)+COALESCE(coordenadores,0)+COALESCE(outros,0))::numeric / NULLIF(total_contatos,0) * 100,2) AS perc_baixa
    FROM analise
    WHERE total_contatos > 0
      AND (COALESCE(analistas,0)+COALESCE(coordenadores,0)+COALESCE(outros,0)) >
          (COALESCE(gestores,0)+COALESCE(diretores,0)+COALESCE(c_level,0))
    ORDER BY perc_baixa DESC;
    """
    try:
        conn = get_conn(); cur = conn.cursor()
        cur.execute(query); dados = cur.fetchall()
        cur.close(); conn.close()
        for d in dados:
            d["insight"] = "Relacionamento predominantemente operacional"
        return resposta_tulipa("ok" if dados else "vazio", "Análise concluída com sucesso", dados)
    except Exception as e:
        logger.error(f"Erro em baixa_decisao: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# 2️⃣ Mapeamento incompleto
@router.get("/mapeamento_incompleto")
def analise_mapeamento_incompleto():
    query = f"""
    WITH analise AS ({SQL_BASE})
    SELECT *
    FROM analise
    WHERE total_contatos > 0
      AND (COALESCE(gestores,0)+COALESCE(diretores,0)+COALESCE(c_level,0)) = 0
      AND (COALESCE(analistas,0)+COALESCE(coordenadores,0)) > 0
    ORDER BY total_contatos DESC;
    """
    try:
        conn = get_conn(); cur = conn.cursor()
        cur.execute(query); dados = cur.fetchall()
        cur.close(); conn.close()
        for d in dados:
            d["insight"] = "Necessário mapear decisores estratégicos"
        return resposta_tulipa("ok" if dados else "vazio", "Análise concluída com sucesso", dados)
    except Exception as e:
        logger.error(f"Erro em mapeamento_incompleto: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# 3️⃣ Hierarquia invertida
@router.get("/hierarquia_invertida")
def analise_hierarquia_invertida():
    query = f"""
    WITH analise AS ({SQL_BASE})
    SELECT *
    FROM analise
    WHERE total_contatos > 0
      AND COALESCE(c_level,0) > 0
      AND COALESCE(analistas,0) > 0
      AND (COALESCE(gestores,0)+COALESCE(coordenadores,0)) = 0
    ORDER BY total_contatos DESC;
    """
    try:
        conn = get_conn(); cur = conn.cursor()
        cur.execute(query); dados = cur.fetchall()
        cur.close(); conn.close()
        for d in dados:
            d["insight"] = "Estrutura hierárquica invertida"
        return resposta_tulipa("ok" if dados else "vazio", "Análise concluída com sucesso", dados)
    except Exception as e:
        logger.error(f"Erro em hierarquia_invertida: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# 4️⃣ Saudável
@router.get("/saudavel")
def analise_saudavel():
    query = f"""
    WITH analise AS ({SQL_BASE})
    SELECT *
    FROM analise
    WHERE total_contatos > 4
      AND COALESCE(c_level,0) > 0
      AND COALESCE(diretores,0) > 0
      AND COALESCE(gestores,0) > 0
      AND COALESCE(analistas,0) > 0;
    """
    try:
        conn = get_conn(); cur = conn.cursor()
        cur.execute(query); dados = cur.fetchall()
        cur.close(); conn.close()
        for d in dados:
            d["insight"] = "Boa cobertura hierárquica e relacionamento completo"
        return resposta_tulipa("ok" if dados else "vazio", "Análise concluída com sucesso", dados)
    except Exception as e:
        logger.error(f"Erro em saudavel: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# 5️⃣ Sem estratégicos
@router.get("/sem_estrategicos")
def analise_sem_estrategicos():
    query = f"""
    WITH analise AS ({SQL_BASE})
    SELECT *
    FROM analise
    WHERE total_contatos > 0
      AND (COALESCE(c_level,0)+COALESCE(diretores,0)+COALESCE(gestores,0)) = 0
    ORDER BY total_contatos DESC;
    """
    try:
        conn = get_conn(); cur = conn.cursor()
        cur.execute(query); dados = cur.fetchall()
        cur.close(); conn.close()
        for d in dados:
            d["insight"] = "Ausência de decisores estratégicos"
        return resposta_tulipa("ok" if dados else "vazio", "Análise concluída com sucesso", dados)
    except Exception as e:
        logger.error(f"Erro em sem_estrategicos: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# 6️⃣ Excesso de genéricos
@router.get("/excesso_outros")
def analise_excesso_outros():
    query = f"""
    WITH analise AS ({SQL_BASE})
    SELECT *, 
           ROUND((COALESCE(outros,0)::numeric / NULLIF(total_contatos,0)) * 100,2) AS perc_outros
    FROM analise
    WHERE total_contatos > 0
      AND (COALESCE(outros,0)::numeric / NULLIF(total_contatos,0)) > 0.5
    ORDER BY perc_outros DESC;
    """
    try:
        conn = get_conn(); cur = conn.cursor()
        cur.execute(query); dados = cur.fetchall()
        cur.close(); conn.close()
        for d in dados:
            d["insight"] = "Baixa qualidade nos dados de cargo"
        return resposta_tulipa("ok" if dados else "vazio", "Análise concluída com sucesso", dados)
    except Exception as e:
        logger.error(f"Erro em excesso_outros: {e}")
        raise HTTPException(status_code=500, detail=str(e))
