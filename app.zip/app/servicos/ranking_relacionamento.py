import logging
from fastapi import APIRouter
from datetime import datetime
from database import get_conn

router = APIRouter()
logger = logging.getLogger("atria_api")


def gerar_insight_principal(total_contatos, c_level, diretores, gestores, coordenadores, analistas, outros):
    """
    Gera um insight textual resumido sobre o relacionamento da conta.
    """

    # ✅ 1️⃣ Nenhum contato mapeado
    if total_contatos == 0:
        return "Conta sem contatos mapeados"

    # ✅ 2️⃣ Poucos contatos (1 ou 2)
    if total_contatos < 3:
        return "Conta com baixíssimo mapeamento de contatos"

    # ✅ 3️⃣ Relacionamento predominantemente operacional
    if c_level == 0 and diretores == 0 and gestores == 0 and coordenadores == 0 and analistas > 0:
        return "Relacionamento predominantemente operacional"

    # ✅ 4️⃣ Alta gestão sem intermediários
    if (c_level > 0 or diretores > 0) and gestores == 0 and coordenadores == 0:
        return "Hierarquia desbalanceada — presença de alta gestão sem liderança intermediária"

    # ✅ 5️⃣ Dados genéricos
    if analistas == 0 and outros > 0 and (c_level + diretores + gestores + coordenadores == 0):
        return "Dados genéricos — recomenda-se melhorar mapeamento da conta"

    # ✅ 6️⃣ Estrutura completa
    if c_level > 0 and diretores > 0 and gestores > 0 and coordenadores > 0 and analistas > 0:
        return "Conta madura e bem mapeada"

    # ✅ 7️⃣ Caso intermediário
    return "Estrutura de relacionamento parcial — requer mapear melhora a estrutra"

# ----------------------------------------------------------
#  Função auxiliar: calcular pontuação e classificação
# ----------------------------------------------------------
def calcular_score_e_classificacao(
    c_level, diretores, gestores, coordenadores, analistas, outros, hierarquia_invertida=False
):
    # Converter valores para inteiros de forma segura
    def to_int(v):
        try:
            return int(v or 0)
        except (ValueError, TypeError):
            return 0

    c_level = to_int(c_level)
    diretores = to_int(diretores)
    gestores = to_int(gestores)
    coordenadores = to_int(coordenadores)
    analistas = to_int(analistas)
    outros = to_int(outros)

    score = 0

    # Pontuação por presença de cada nível hierárquico
    if c_level > 0:
        score += 40
    if diretores > 0:
        score += 25
    if gestores > 0:
        score += 20
    if coordenadores > 0:
        score += 10
    if analistas > 0:
        score += 5
    if outros > 0 and (c_level + diretores + gestores + coordenadores + analistas == 0):
        score -= 20

    # Penalização por hierarquia invertida
    if hierarquia_invertida:
        score -= 15

    # Normalizar limites
    if score < 0:
        score = 0
    if score > 100:
        score = 100

    # Classificação profissional
    if score >= 85:
        classificacao = "A - MadMadura e bem mapeada" #Mapeamento completo e equilibrado em todos os níveis hierárquicos, com relacionamentos consolidados e estruturados.
    elif score >= 65:
        classificacao = "B - Consolidada, aprimorar conexões" #Estrutura consistente e ativa, mas ainda com espaço para expandir conexões estratégicas.
    elif score >= 45:
        classificacao = "C - Em desenvolvimento"  #Estrutura parcialmente mapeada, com representação limitada de alguns níveis hierárquicos.
    elif score >= 25:
        classificacao = "D - Fraca, limitada e fragmentada" #Contatos concentrados em poucas áreas ou níveis, dificultando amplitude de relacionamento.
    else:
        classificacao = "E - Precária" #Falta de mapeamento relevante ou ausência de contatos. Exige ações imediatas de prospecção.

    return score, classificacao

# ----------------------------------------------------------
#  Rota 1 — Ranking geral
# ----------------------------------------------------------
@router.post("/ranking_geral")
def gerar_ranking_geral():
    """
    Gera ou atualiza o ranking de relacionamento de todas as contas.
    """
    try:
        conn = get_conn()
        cur = conn.cursor()

        # Buscar dados agregados por conta
        cur.execute("""
            SELECT 
                c.id AS conta_id,
                c.nome,
                COUNT(ct.id) AS total_contatos,
                SUM(CASE WHEN nh.nome ILIKE '%c-level%' THEN 1 ELSE 0 END) AS c_level,
                SUM(CASE WHEN nh.nome ILIKE '%diretor%' THEN 1 ELSE 0 END) AS diretores,
                SUM(CASE WHEN nh.nome ILIKE '%gerente%' THEN 1 ELSE 0 END) AS gestores,
                SUM(CASE WHEN nh.nome ILIKE '%coordenador%' THEN 1 ELSE 0 END) AS coordenadores,
                SUM(CASE WHEN nh.nome ILIKE '%analista%' THEN 1 ELSE 0 END) AS analistas,
                SUM(CASE WHEN nh.nome ILIKE '%outros%' OR nh.nome IS NULL THEN 1 ELSE 0 END) AS outros
            FROM contas c
            LEFT JOIN contatos ct ON c.id = ct.empresa_id
            LEFT JOIN nivel_hierarquico nh ON ct.nivel_hierarquico_id = nh.id
            GROUP BY c.id, c.nome
        """)

        contas = cur.fetchall()
        total = 0
        dados_ranking = []

        for row in contas:
            conta_id = int(row["conta_id"] or 0)
            nome = row["nome"]

            # Garantir inteiros
            total_contatos = int(row["total_contatos"] or 0)
            c_level = int(row["c_level"] or 0)
            diretores = int(row["diretores"] or 0)
            gestores = int(row["gestores"] or 0)
            coordenadores = int(row["coordenadores"] or 0)
            analistas = int(row["analistas"] or 0)
            outros = int(row["outros"] or 0)

            score, classificacao = calcular_score_e_classificacao(
                c_level, diretores, gestores, coordenadores, analistas, outros
            )

            insight = gerar_insight_principal(
               total_contatos, c_level, diretores, gestores, coordenadores, analistas, outros
            )

            cur.execute("""
                INSERT INTO analise_relacionamento (
                    conta_id, nome, total_contatos, c_level, diretores, gestores, 
                    coordenadores, analistas, outros, score, classificacao, insight_principal, atualizado_em
                ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, NOW())
                ON CONFLICT (conta_id) DO UPDATE SET
                    total_contatos = EXCLUDED.total_contatos,
                    c_level = EXCLUDED.c_level,
                    diretores = EXCLUDED.diretores,
                    gestores = EXCLUDED.gestores,
                    coordenadores = EXCLUDED.coordenadores,
                    analistas = EXCLUDED.analistas,
                    outros = EXCLUDED.outros,
                    score = EXCLUDED.score,
                    classificacao = EXCLUDED.classificacao,
                    insight_principal = EXCLUDED.insight_principal,
                    atualizado_em = NOW();
            """, (
                conta_id, nome, total_contatos, c_level, diretores, gestores,
                coordenadores, analistas, outros, score, classificacao, insight
            ))

            dados_ranking.append({
                "conta_id": conta_id,
                "nome": nome,
                "score": score,
                "classificacao": classificacao,
                "insight": insight
            })
            total += 1

        conn.commit()
        cur.close()
        conn.close()

        # Retorno padrão Tulipa
        return {
            "status": "ok",
            "mensagem": "Ranking de relacionamento atualizado com sucesso",
            "total": total,
            "dados": sorted(dados_ranking, key=lambda x: x["score"], reverse=True)
        }

    except Exception as e:
        logger.exception("Erro ao gerar ranking de relacionamento")
        return {"status": "erro", "mensagem": str(e)}


# ----------------------------------------------------------
#  Rota 2 — Ranking por empresa
# ----------------------------------------------------------
@router.get("/ranking_empresa/{conta_id}")
def obter_ranking_empresa(conta_id: int):
    """
    Retorna o ranking e classificação de uma empresa específica.
    """
    try:
        conn = get_conn()
        cur = conn.cursor()
        cur.execute("""
            SELECT 
                conta_id, nome, total_contatos, score, classificacao, insight_principal, atualizado_em
            FROM analise_relacionamento
            WHERE conta_id = %s
        """, (conta_id,))
        row = cur.fetchone()
        cur.close()
        conn.close()

        if not row:
            return {"status": "erro", "mensagem": f"Nenhuma análise encontrada para conta {conta_id}"}

        (conta_id, nome, total_contatos, score, classificacao, insight, atualizado_em) = row

        return {
            "status": "ok",
            "mensagem": "Análise de relacionamento recuperada com sucesso",
            "dados": {
                "conta_id": conta_id,
                "nome": nome,
                "total_contatos": total_contatos,
                "score": score,
                "classificacao": classificacao,
                "insight": insight,
                "atualizado_em": atualizado_em
            }
        }

    except Exception as e:
        logger.exception("Erro ao buscar ranking por empresa")
        return {"status": "erro", "mensagem": str(e)}
