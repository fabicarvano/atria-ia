import os
import psycopg2
from psycopg2.extras import RealDictCursor
from fastapi import APIRouter, Depends, HTTPException
from auth import get_current_user

router = APIRouter()

# 🔌 Conexão com o banco no padrão do projeto
def get_db():
    conn = psycopg2.connect(
        host=os.getenv("DB_HOST"),
        port=os.getenv("DB_PORT"),
        database=os.getenv("DB_NAME"),
        user=os.getenv("DB_USER"),
        password=os.getenv("DB_PASS"),
        cursor_factory=RealDictCursor
    )
    return conn


def encontrar_superior(contato, contatos):
    """
    Define quem é o superior imediato de um contato dentro da hierarquia.
    """
    nivel = contato["nivel_hierarquico_id"]
    depto = contato["departamento_id"]

    # Se o contato não tem nível hierárquico definido, não dá pra calcular
    if nivel is None:
        return None

    # regra de precedência: níveis menores = mais alto na hierarquia
    superiores = [
        c for c in contatos
        if c["id"] != contato["id"]
        and c["nivel_hierarquico_id"] is not None
        and c["nivel_hierarquico_id"] < nivel
    ]

    # 1. Se existir no mesmo departamento
    mesmos = [s for s in superiores if s["departamento_id"] == depto]
    if mesmos:
        return sorted(mesmos, key=lambda x: x["nivel_hierarquico_id"])[0]["id"]

    # 2. Caso contrário, escolhe o mais alto da empresa
    if superiores:
        return sorted(superiores, key=lambda x: x["nivel_hierarquico_id"])[0]["id"]

    return None


# 🚀 Rota para recalcular hierarquia de uma empresa
@router.post("/recalcular/{empresa_id}")
def recalcular_hierarquia_contatos(empresa_id: int, user=Depends(get_current_user)):
    """
    Recalcula a hierarquia de 'reporta_a' para todos os contatos de uma empresa.
    """
    try:
        conn = get_db()
        cur = conn.cursor()

        cur.execute("""
            SELECT id, nome, nivel_hierarquico_id, departamento_id
            FROM contatos
            WHERE empresa_id = %s
        """, (empresa_id,))
        contatos = cur.fetchall()

        if not contatos:
            raise HTTPException(status_code=404, detail="Nenhum contato encontrado para esta empresa")

        atualizados = []
        for contato in contatos:
            superior_id = encontrar_superior(contato, contatos)

            cur.execute("""
                UPDATE contatos
                SET reporta_a = %s
                WHERE id = %s
            """, (superior_id, contato["id"]))
            atualizados.append({
                "id": contato["id"],
                "reporta_a": superior_id
            })

        conn.commit()
        cur.close()
        conn.close()

        return {
            "status": "ok",
            "empresa_id": empresa_id,
            "contatos_atualizados": atualizados
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro ao recalcular hierarquia: {str(e)}")


# Função auxiliar de classificação
def classificar_nivel(cargo: str) -> int:
    if not cargo:
        return 6  # Outro

    cargo = cargo.lower()

    if any(x in cargo for x in ["cio", "ceo", "cfo", "cto"]):
        return 1  # C-Level
    elif "diretor" in cargo or "superintendente" in cargo:
        return 2  # Diretor
    elif "gerente" in cargo or "manager" in cargo or "chefe" in cargo:
        return 3  # Gestor
    elif "coordenador" in cargo or "supervisor" in cargo:
        return 4  # Coordenador
    elif "analista" in cargo or "especialista" in cargo or "administrador" in cargo:
        return 5  # Analista
    else:
        return 6  # Outro



#Classificar contatos por emnpresa
@router.post("/{empresa_id}/classificar")
def classificar_contatos_empresa(
    empresa_id: int,
    current_user: dict = Depends(get_current_user)
):
    conn = get_db()
    cur = conn.cursor()

    cur.execute("SELECT id, cargo FROM contatos WHERE empresa_id = %s", (empresa_id,))
    contatos = cur.fetchall()

    atualizados = []
    for contato in contatos:
        contato_id = contato["id"]
        cargo = contato["cargo"]

        nivel_id = classificar_nivel(cargo)
        cur.execute(
            "UPDATE contatos SET nivel_hierarquico_id = %s WHERE id = %s",
            (nivel_id, contato_id)
     )
    atualizados.append({"id": contato_id, "nivel": nivel_id})

    conn.commit()
    cur.close()
    conn.close()

    return {"status": "ok", "empresa_id": empresa_id, "atualizados": len(atualizados)}
