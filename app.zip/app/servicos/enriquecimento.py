# /atria.ia.br/app/servicos/enriquecimento.py

# ==========================
# 🔹 Imports
# ==========================
import os
import re
import json
import psycopg2
import requests
from typing import List, Optional
from urllib.parse import urlparse
from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
from dotenv import load_dotenv
from apify_client import ApifyClient

from auth import get_current_user
from openai import OpenAI  # usado apenas na validação de consistência

# ==========================
# 🔹 Configurações iniciais
# ==========================
load_dotenv()
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
DATABASE_URL = os.getenv("DATABASE_URL")
APIFY_TOKEN = os.getenv("APIFY_LINKEDIN_COMPANY_KEY")
PERPLEXY_API = os.getenv("PERPLEXY_API")
PERPLEXITY_SEARCH_URL = "https://api.perplexity.ai/search"

if not OPENAI_API_KEY:
    raise RuntimeError("❌ OPENAI_API_KEY não configurada no .env")
if not DATABASE_URL:
    raise RuntimeError("❌ DATABASE_URL não configurada no .env")
if not APIFY_TOKEN:
    raise RuntimeError("❌ APIFY_LINKEDIN_COMPANY_KEY não configurada no .env")
if not PERPLEXY_API:
    raise RuntimeError("❌ PERPLEXY_API não configurada no .env")

client = OpenAI(api_key=OPENAI_API_KEY)
apify_client = ApifyClient(APIFY_TOKEN)

# ==========================
# 🔹 Router do módulo
# ==========================
router = APIRouter(dependencies=[Depends(get_current_user)])

# ==========================
# 🔹 Conexão com banco
# ==========================
def get_conn():
    return psycopg2.connect(DATABASE_URL)

# ==========================
# 🔹 Funções auxiliares de CNPJ
# ==========================
def limpar_cnpj(cnpj: str) -> str:
    return re.sub(r"\D", "", cnpj)

def verificar_tipo_estabelecimento(cnpj: str) -> str:
    cnpj = re.sub(r"\D", "", cnpj)
    if len(cnpj) != 14:
        return "desconhecido"
    if cnpj[8:12] == "0001":
        return "matriz"
    return "filial"

def buscar_dados_receitaws(cnpj: str) -> dict:
    url = f"https://receitaws.com.br/v1/cnpj/{cnpj}"
    try:
        r = requests.get(url, timeout=20)
        if r.status_code != 200:
            raise Exception(f"Erro ReceitaWS ({r.status_code}): {r.text}")
        dados = r.json()
        atividade = (dados.get("atividade_principal") or [{}])[0]
        return {
            "nome": dados.get("nome"),
            "logradouro": dados.get("logradouro"),
            "numero": dados.get("numero"),
            "municipio": dados.get("municipio"),
            "uf": dados.get("uf"),
            "capital_social": dados.get("capital_social"),
            "cnae_code": atividade.get("code"),
            "cnae_text": atividade.get("text"),
            "email": dados.get("email"),
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro ao consultar ReceitaWS: {e}")

# ==========================
# 🔹 Rota CNPJ - ENRIQUECIMENTO
# ==========================
@router.post("/cnpj/{conta_id}")
async def enriquecer_por_cnpj(conta_id: int, current_user: dict = Depends(get_current_user)):
    """
    Enriquece dados da conta através de consulta CNPJ na ReceitaWS
    
    - **conta_id**: ID da conta a ser enriquecida
    
    Retorna:
    - Dados oficiais da empresa obtidos via CNPJ
    
    Erros:
    - 404: Conta não encontrada
    - 400: Conta sem CNPJ cadastrado
    - 500: Erro interno do servidor ou na consulta ReceitaWS
    """
    conn = get_conn()
    cur = conn.cursor()

    try:
        cur.execute("SELECT nome, cnpj FROM contas WHERE id = %s", (conta_id,))
        row = cur.fetchone()

        if not row:
            raise HTTPException(status_code=404, detail="Conta não encontrada")

        nome, cnpj = row
        if not cnpj:
            raise HTTPException(status_code=400, detail="Conta sem CNPJ cadastrado")

        cnpj_limpo = limpar_cnpj(cnpj)
        tipo_estab = verificar_tipo_estabelecimento(cnpj_limpo)

        dados = buscar_dados_receitaws(cnpj_limpo)
        razao = dados.get("nome")
        endereco = f"{dados.get('logradouro', '')}, {dados.get('numero', '')}".strip(", ")
        cidade = dados.get("municipio")
        estado = dados.get("uf")
        capital_social = dados.get("capital_social")
        cnae_code = dados.get("cnae_code")
        cnae_text = dados.get("cnae_text")
        email_receita = dados.get("email")

        cur.execute("""
            UPDATE contas
            SET razao_social = %s,
                endereco = %s,
                cidade = %s,
                estado = %s,
                capital_social = %s,
                tipo_estabelecimento = %s,
                cnae_code = %s,
                cnae_text = %s,
                email = %s,
                atualizado_em = NOW()
            WHERE id = %s
        """, (
            razao, endereco, cidade, estado,
            capital_social, tipo_estab, cnae_code, cnae_text, 
            email_receita, conta_id
        ))
        conn.commit()

        return {
            "status": "ok",
            "conta_id": conta_id,
            "nome": nome,
            "cnpj": cnpj_limpo,
            "razao_social": razao,
            "tipo_estabelecimento": tipo_estab,
            "cidade": cidade,
            "estado": estado,
            "capital_social": capital_social,
            "cnae_code": cnae_code,
            "cnae_text": cnae_text,
            "email": email_receita
        }

    except Exception as e:
        conn.rollback()
        print(f"❌ ERRO CNPJ: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Erro ao enriquecer por CNPJ: {str(e)}")

    finally:
        cur.close()
        conn.close()

# ==========================
# 🔹 Rota LinkedIn - ENRIQUECIMENTO
# ==========================
@router.post("/linkedin/{conta_id}")
async def enriquecer_por_linkedin(conta_id: int, current_user: dict = Depends(get_current_user)):
    """
    Enriquece dados da conta através de busca no LinkedIn via Apify
    
    - **conta_id**: ID da conta a ser enriquecida
    
    Atualiza tabela contas com dados da empresa principal e 
    insere empresas similares na tabela contas_similares
    
    Retorna:
    - Dados do LinkedIn da empresa principal e quantidade de similares inseridas
    
    Erros:
    - 404: Conta não encontrada
    - 400: Empresa não encontrada no LinkedIn
    - 500: Erro interno do servidor ou na API Apify
    """
    conn = get_conn()
    cur = conn.cursor()

    try:
        # Verificar se conta existe
        cur.execute("SELECT id, nome FROM contas WHERE id = %s", (conta_id,))
        row = cur.fetchone()
        
        if not row:
            raise HTTPException(status_code=404, detail="Conta não encontrada")

        conta_id_db, nome = row

        # Usar Apify Client corretamente
        run_input = {
            "companies": [nome]  # Sempre enviar nome da conta
        }

        try:
            # Executar Actor Apify
            run = apify_client.actor("UwSdACBp7ymaGUJjS").call(run_input=run_input)
            
            # Obter resultados
            dados_linkedin = []
            for item in apify_client.dataset(run["defaultDatasetId"]).iterate_items():
                dados_linkedin.append(item)
                
        except Exception as e:
            print(f"❌ ERRO APIFY: {str(e)}")
            raise HTTPException(status_code=500, detail=f"Erro na API Apify: {str(e)}")
        
        if not dados_linkedin or len(dados_linkedin) == 0:
            # Não dar erro, apenas retornar sem dados
            return {
                "status": "ok",
                "conta_id": conta_id_db,
                "message": "Empresa não encontrada no LinkedIn",
                "similares_inseridas": 0
            }

        # A empresa principal é o primeiro resultado
        empresa_principal = dados_linkedin[0]
        
        # Extrair dados da empresa principal
        linkedin_url = empresa_principal.get("linkedinUrl", "")
        funcionarios = empresa_principal.get("employeeCount")
        numero_seguidores = empresa_principal.get("followerCount")
        
        # Site - pegar do campo website do LinkedIn
        site = empresa_principal.get("website", "")
        
        # Logo - pegar da propriedade logo ou do primeiro item de logos
        logo_url = empresa_principal.get("logo", "")
        if not logo_url and empresa_principal.get("logos"):
            logo_url = empresa_principal["logos"][0].get("url", "")
        
        # Indústria - pegar primeiro item do array (objeto com name)
        industria = ""
        if empresa_principal.get("industries") and len(empresa_principal["industries"]) > 0:
            industria = empresa_principal["industries"][0].get("name", "")
        
        descricao_oficial = empresa_principal.get("description", "")
        
        # Especialidades - juntar array em string
        especialidades = ""
        if empresa_principal.get("specialities"):
            especialidades = ", ".join(empresa_principal["specialities"])

        # Atualizar tabela contas (empresa principal)
        cur.execute("""
            UPDATE contas
            SET linkedin = %s,
                funcionarios = %s,
                numero_seguidores = %s,
                logo_url = %s,
                industria = %s,
                descricao_oficial = %s,
                especialidade = %s,
                site = %s,
                atualizado_em = NOW()
            WHERE id = %s
        """, (
            linkedin_url, funcionarios, numero_seguidores, 
            logo_url, industria, descricao_oficial, especialidades, 
            site, conta_id_db
        ))

        # Inserir empresas similares do array similarOrganizations
        similares_inseridas = 0
        similar_organizations = empresa_principal.get("similarOrganizations", [])
        
        for empresa_similar in similar_organizations:
            # Extrair dados da empresa similar
            similar_linkedin_url = empresa_similar.get("linkedinUrl", "")
            similar_nome = empresa_similar.get("name", "")
            
            # Logo da empresa similar
            similar_logo_url = empresa_similar.get("logo", "")
            
            similar_follower_count = empresa_similar.get("followerCount")
            
            similar_descricao = empresa_similar.get("description", "")
            
            # Indústria da empresa similar (objeto com name)
            similar_industria = ""
            if empresa_similar.get("industries") and len(empresa_similar["industries"]) > 0:
                similar_industria = empresa_similar["industries"][0].get("name", "")
            
            # JSON completo da empresa similar
            dados_json = json.dumps(empresa_similar)

            # Inserir na tabela contas_similares
            cur.execute("""
                INSERT INTO contas_similares 
                (conta_id, linkedin_url, nome, logo_url, follower_count, 
                 descricao, dados, industria, criado_em)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, NOW())
            """, (
                conta_id_db, similar_linkedin_url, similar_nome, similar_logo_url,
                similar_follower_count, similar_descricao, 
                dados_json, similar_industria
            ))
            
            similares_inseridas += 1

        conn.commit()

        return {
            "status": "ok",
            "conta_id": conta_id_db,
            "empresa_principal": {
                "linkedin": linkedin_url,
                "funcionarios": funcionarios,
                "numero_seguidores": numero_seguidores,
                "logo_url": logo_url,
                "industria": industria,
                "descricao_oficial": descricao_oficial,
                "especialidade": especialidades,
                "site": site
            },
            "similares_inseridas": similares_inseridas,
            "total_similares_encontradas": len(similar_organizations)
        }

    except Exception as e:
        conn.rollback()
        print(f"❌ ERRO LINKEDIN: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Erro ao enriquecer por LinkedIn: {str(e)}")

    finally:
        cur.close()
        conn.close()

# ==========================
# 🔹 Função de validação de consistência
# ==========================
def validar_consistencia_descricoes(descricao_oficial, descricao):
    """Valida se duas descrições se referem à mesma empresa usando OpenAI"""
    if not descricao_oficial or not descricao:
        return True
    
    desc_a = descricao_oficial[:500]
    desc_b = descricao[:500]
    
    prompt = f"""
    Compare estas duas descrições e responda APENAS com SIM ou NAO se falam da mesma empresa.
    Responda em português, apenas com uma palavra (SIM ou NAO).

    A: {desc_a}
    B: {desc_b}
    """
    
    try:
        validacao = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": prompt}]
        )
        resposta = validacao.choices[0].message.content.strip().upper()
        return resposta.startswith("SIM")
    except Exception as e:
        print(f"❌ Erro na validação de consistência: {e}")
        return False  # Retorna False em caso de erro para ser mais conservador

def validar_site_com_descricao(site, descricao_oficial):
    """Valida se o site corresponde à descrição usando Perplexity"""
    if not site or not descricao_oficial:
        return True
    
    query = f"""
TAREFA: Verificar se o site e a descrição correspondem à MESMA empresa.

SITE: {site}
DESCRIÇÃO: {descricao_oficial[:400]}

INSTRUÇÕES:
- Acesse o site e compare com a descrição fornecida
- Se forem da mesma empresa: responda "COMPATÍVEL"
- Se forem de empresas diferentes: responda "INCOMPATÍVEL"
- Ignore diferenças de idioma (português/inglês)
- Foque na atividade principal, setor e localização
- Considere variações de nome da empresa como normais

RESPOSTA (uma palavra apenas): COMPATÍVEL ou INCOMPATÍVEL
    """
    
    try:
        r = requests.post(
            PERPLEXITY_SEARCH_URL,
            headers={
                "Authorization": f"Bearer {PERPLEXY_API}",
                "Content-Type": "application/json",
            },
            json={"query": query},
            timeout=30
        )
        
        if r.status_code == 200:
            dados = r.json()
            resposta = dados.get("answer", "").strip().upper()
            
            # Verificar múltiplas palavras-chave para compatibilidade
            palavras_compativel = ["COMPATÍVEL", "SIM", "COMPATIBLE", "YES", "CORRESPONDE", "MESMA"]
            palavras_incompativel = ["INCOMPATÍVEL", "NÃO", "NAO", "INCOMPATIBLE", "NO", "DIFERENTE"]
            
            # Se encontrar palavra de compatibilidade, retornar True
            if any(palavra in resposta for palavra in palavras_compativel):
                return True
            
            # Se encontrar palavra de incompatibilidade, retornar False
            if any(palavra in resposta for palavra in palavras_incompativel):
                return False
            
            # Se resposta ambígua ou vazia, assumir compatível (evitar falsos positivos)
            return True
        else:
            print(f"❌ Erro Perplexity status {r.status_code}: {r.text[:200]}")
            return True  # Em caso de erro, assumir que está correto
            
    except Exception as e:
        print(f"❌ Erro na validação de site: {e}")
        return True

# ==========================
# 🔹 Rota Validação de Inconsistências (OTIMIZADA)
# ==========================
@router.post("/validar-inconsistencias/{conta_id}")
async def validar_inconsistencias(conta_id: int, current_user: dict = Depends(get_current_user)):
    """
    Valida inconsistências de uma conta específica

    Regras aplicadas:
    - **Falha no enriquecimento** → quando não existe `descricao_oficial`
    - **Descrição inconsistente com site** → quando `descricao_oficial` e `descricao` existem,
      mas a IA entende que não correspondem à mesma empresa
    - **CNPJ cadastrado de filial** → quando o CNPJ não é matriz (posições 9-12 ≠ "0001")
    - **Indústria não informada** → quando campo `industria` está vazio ou null
    - **Site não encontrado** → quando campo `site` está vazio ou null
    - **Site inconsistente** → quando site não corresponde à descrição oficial

    Retorna:
    - **status**: "ok"
    - **inconsistencias**: lista de inconsistências da conta

    Erros:
    - 404: Conta não encontrada
    - 500: Erro interno ao processar a validação
    """
    try:
        conn = get_conn()
        cur = conn.cursor()

        # Buscar APENAS a conta específica
        cur.execute("""
            SELECT id, descricao_oficial, descricao, inconsistencias, cnpj, industria, site
            FROM contas WHERE id = %s
        """, (conta_id,))
        
        row = cur.fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Conta não encontrada")

        conta_id, desc_oficial, desc, inconsistencias, cnpj, industria, site = row
        inconsistencias = inconsistencias or []

        # 1. Falha no enriquecimento
        if not desc_oficial and "Falha no enriquecimento" not in inconsistencias:
            inconsistencias.append("Falha no enriquecimento")

        # 2. Descrição inconsistente (apenas se ambas existirem e forem substanciais)
        if (desc_oficial and desc and 
            len(desc_oficial) > 50 and len(desc) > 50):
            if not validar_consistencia_descricoes(desc_oficial, desc):
                if "Descrição inconsistente com site" not in inconsistencias:
                    inconsistencias.append("Descrição inconsistente com site")

        # 3. CNPJ filial
        if cnpj:
            cnpj_limpo = limpar_cnpj(cnpj)
            if verificar_tipo_estabelecimento(cnpj_limpo) == "filial":
                if "CNPJ cadastrado de filial" not in inconsistencias:
                    inconsistencias.append("CNPJ cadastrado de filial")

        # 4. Indústria vazia (verificar se realmente está vazia)
        if (not industria or industria.strip() == "") and "Indústria não informada" not in inconsistencias:
            inconsistencias.append("Indústria não informada")

        # 5. Site não encontrado
        if not site and "Site não encontrado" not in inconsistencias:
            inconsistencias.append("Site não encontrado")

        # 6. Site inconsistente com descrição (usar Perplexity)
        if (site and desc_oficial and 
            len(desc_oficial) > 50):
            if not validar_site_com_descricao(site, desc_oficial):
                if "Site inconsistente com descrição" not in inconsistencias:
                    inconsistencias.append("Site inconsistente com descrição")

        # Atualizar banco
        cur.execute("""
            UPDATE contas
            SET inconsistencias = %s,
                atualizado_em = NOW()
            WHERE id = %s
        """, (inconsistencias, conta_id))

        conn.commit()
        cur.close()
        conn.close()

        return {
            "status": "ok", 
            "conta_id": conta_id,
            "inconsistencias": inconsistencias
        }

    except Exception as e:
        if 'conn' in locals():
            conn.rollback()
            cur.close()
            conn.close()
        print(f"❌ ERRO VALIDAÇÃO: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Erro ao validar inconsistências: {str(e)}")

# ==========================
# 🔹 Modelo Pydantic para Padronização de Setor
# ==========================
class PadronizarSetorRequest(BaseModel):
    nome_industria: str

# ==========================
# 🔹 Rota Padronização de Setor
# ==========================
@router.post("/padronizar-setor")
async def padronizar_setor(
    request: PadronizarSetorRequest, 
    current_user: dict = Depends(get_current_user)
):
    conn = get_conn()
    cur = conn.cursor()

    try:
        nome_industria = request.nome_industria.strip()
        
        if not nome_industria:
            raise HTTPException(status_code=400, detail="Nome da indústria não pode estar vazio")

        # 1. Buscar mapeamento existente
        cur.execute("""
            SELECT i.setor_id, s.nome 
            FROM industria_setor i
            JOIN setores s ON i.setor_id = s.id
            WHERE LOWER(i.nome_industria) = LOWER(%s)
        """, (nome_industria,))
        
        resultado = cur.fetchone()
        
        if resultado:
            setor_id, nome_setor = resultado
            # ✅ Atualizar contas mesmo se já existir mapeamento
            cur.execute("""
                UPDATE contas
                SET setor_id = %s,
                    atualizado_em = NOW()
                WHERE LOWER(industria) = LOWER(%s)
            """, (setor_id, nome_industria))
            conn.commit()

            return {
                "status": "ok",
                "nome_industria": nome_industria,
                "setor_id": setor_id,
                "nome_setor": nome_setor,
                "mapeamento_criado": False,
                "fonte": "mapeamento_existente"
            }

        # 2. Buscar todos os setores disponíveis
        cur.execute("SELECT id, nome FROM setores ORDER BY id")
        setores_disponiveis = cur.fetchall()
        setores_lista = "\n".join([f"{s[0]}. {s[1]}" for s in setores_disponiveis])

        # 3. Usar IA
        prompt = f"""
        Você deve mapear a indústria "{nome_industria}" para um dos setores brasileiros abaixo.
        
        SETORES DISPONÍVEIS:
        {setores_lista}
        
        Regras:
        - Responda APENAS com o número do setor
        """
        try:
            resposta_ia = client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[{"role": "user", "content": prompt}],
                temperature=0.1
            )
            setor_id = int(resposta_ia.choices[0].message.content.strip())
            cur.execute("SELECT nome FROM setores WHERE id = %s", (setor_id,))
            nome_setor = cur.fetchone()[0]
        except Exception as e:
            print(f"❌ ERRO IA MAPEAMENTO: {str(e)}")
            setor_id = 13
            cur.execute("SELECT nome FROM setores WHERE id = %s", (setor_id,))
            nome_setor = cur.fetchone()[0]

        # 4. Inserir mapeamento
        cur.execute("""
            INSERT INTO industria_setor (nome_industria, setor_id)
            VALUES (%s, %s)
        """, (nome_industria, setor_id))

        # 5. Atualizar contas
        cur.execute("""
            UPDATE contas
            SET setor_id = %s,
                atualizado_em = NOW()
            WHERE LOWER(industria) = LOWER(%s)
        """, (setor_id, nome_industria))

        conn.commit()

        return {
            "status": "ok",
            "nome_industria": nome_industria,
            "setor_id": setor_id,
            "nome_setor": nome_setor,
            "mapeamento_criado": True,
            "fonte": "mapeamento_ia"
        }

    except Exception as e:
        conn.rollback()
        print(f"❌ ERRO PADRONIZAR SETOR: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Erro ao padronizar setor: {str(e)}")

    finally:
        cur.close()
        conn.close()

# ==========================
# 🔹 Rota Limpeza de Campos Vazios
# ==========================
@router.post("/limpar-campos-vazios/{conta_id}")
async def limpar_campos_vazios(conta_id: int, current_user: dict = Depends(get_current_user)):
    """
    Converte strings vazias em NULL para uma conta específica
    
    - **conta_id**: ID da conta a ser limpa
    
    Retorna:
    - Quantidade de campos limpos
    
    Erros:
    - 404: Conta não encontrada
    - 500: Erro interno do servidor
    """
    conn = get_conn()
    cur = conn.cursor()

    try:
        # Verificar se conta existe
        cur.execute("SELECT id FROM contas WHERE id = %s", (conta_id,))
        if not cur.fetchone():
            raise HTTPException(status_code=404, detail="Conta não encontrada")

        # Limpar campos vazios (converter '' em NULL)
        cur.execute("""
            UPDATE contas
            SET razao_social = NULLIF(razao_social, ''),
                site = NULLIF(site, ''),
                linkedin = NULLIF(linkedin, ''),
                endereco = NULLIF(endereco, ''),
                descricao = NULLIF(descricao, ''),
                descricao_oficial = NULLIF(descricao_oficial, ''),
                logo_url = NULLIF(logo_url, ''),
                industria = NULLIF(industria, ''),
                especialidade = NULLIF(especialidade, ''),
                email = NULLIF(email, ''),
                cnae_code = NULLIF(cnae_code, ''),
                cnae_text = NULLIF(cnae_text, ''),
                categoria = NULLIF(categoria, ''),
                contatos = NULLIF(contatos, ''),
                atualizado_em = NOW()
            WHERE id = %s
        """, (conta_id,))
        
        campos_limpos = cur.rowcount
        conn.commit()

        return {
            "status": "ok",
            "conta_id": conta_id,
            "campos_limpos": campos_limpos
        }

    except Exception as e:
        conn.rollback()
        print(f"❌ ERRO LIMPEZA: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Erro ao limpar campos vazios: {str(e)}")

    finally:
        cur.close()
        conn.close()
