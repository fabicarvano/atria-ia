# /atria.ia.br/app/enriquecimento_contato.py
# ---------------------------
# Bibliotecas padrão
# ---------------------------
import os
import re
import json
import unicodedata
from typing import Dict, List, Any, Optional

# ---------------------------
# FastAPI / Pydantic
# ---------------------------
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

# ---------------------------
# Config / Variáveis de ambiente
# ---------------------------
from dotenv import load_dotenv

# ---------------------------
# Conexão banco / autenticação
# ---------------------------
from auth import get_current_user
from database import get_conn

# ---------------------------
# Clientes externos
# ---------------------------
from apify_client import ApifyClient
from openai import OpenAI

# 🔒 Router protegido por JWT (conforme guia)
router = APIRouter(dependencies=[Depends(get_current_user)])

# 🔑 Carregar variáveis do .env
load_dotenv()
CHAVE_APIFY = os.getenv("APIFY_LINKEDIN_COMPANY_KEY")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")


client = OpenAI(api_key=OPENAI_API_KEY)


# ---------------------------
# Modelos Pydantic
# ---------------------------

class RecomendacoesResponse(BaseModel):
    received: List[str]
    given: List[str]


class ExperienciaResponse(BaseModel):
    empresa: Optional[str]
    cargo: Optional[str]
    inicio: Optional[str]
    fim: Optional[str]
    descricao: Optional[str]


class EnriquecimentoResponse(BaseModel):
    id: int
    status: str
    seguidores: Optional[int]
    conexoes: Optional[int]
    resumo: Optional[str]
    url_foto_perfil: Optional[str]
    recomendacoes: RecomendacoesResponse
    experiencias_total: int
    certificacoes: List[str]


# ---------------------------
# Funções Auxiliares
# ---------------------------

def _remover_duplicados_lista(valores: List[str]) -> List[str]:
    """Remove duplicados preservando ordem."""
    vistos = set()
    resultado = []
    for valor in valores:
        if valor and valor not in vistos:
            resultado.append(valor)
            vistos.add(valor)
    return resultado


def _extrair_datas_da_legenda(legenda: Optional[str]) -> Dict[str, Optional[str]]:
    """
    Recebe legendas do tipo:
      - "May 2022 - Present · 3 yrs 6 mos"
      - "Oct 2018 - May 2022 · 3 yrs 8 mos"
      - "Mar 2014 - Oct 2018 · 4 yrs 8 mos"
      - Ou, em alguns históricos simples, pode trazer apenas intervalo sem '· ...'

    Retorna {"inicio": "YYYY-MM" ou "YYYY", "fim": "YYYY-MM"/"YYYY"/None}
    (heurística simples, robusta o suficiente para o enriquecimento; evita quebrar em formatos diferentes)
    """
    if not legenda:
        return {"inicio": None, "fim": None}

    # Pegamos só a parte antes do separador de duração "·"
    principal = legenda.split("·")[0].strip()

    # Ex.: "May 2022 - Present" / "Sep 2008 - Aug 2012" / "2007 - 2008"
    partes = [p.strip() for p in principal.split("-")]
    if len(partes) != 2:
        return {"inicio": principal or None, "fim": None}

    inicio_bruto, fim_bruto = partes[0], partes[1]

    # Normalização simples: tentar (Mon YYYY) ou (YYYY)
    mapa_meses = {
        "Jan": "01", "Feb": "02", "Mar": "03", "Apr": "04", "May": "05", "Jun": "06",
        "Jul": "07", "Aug": "08", "Sep": "09", "Oct": "10", "Nov": "11", "Dec": "12"
    }

    def normalizar_data(texto: str) -> Optional[str]:
        texto = texto.strip()
        if not texto or texto.lower() == "present":
            return None
        # Tenta "Mon YYYY"
        correspondencia = re.match(r"([A-Za-z]{3})\s+(\d{4})", texto)
        if correspondencia and correspondencia.group(1)[:3].title() in mapa_meses:
            return f"{correspondencia.group(2)}-{mapa_meses[correspondencia.group(1)[:3].title()]}"
        # Tenta apenas "YYYY"
        correspondencia = re.match(r"(\d{4})$", texto)
        if correspondencia:
            return correspondencia.group(1)
        # fallback bruto
        return texto

    inicio = normalizar_data(inicio_bruto)
    fim = normalizar_data(fim_bruto)

    return {"inicio": inicio, "fim": fim}


def _normalizar_experiencias(perfil: Dict[str, Any]) -> List[Dict[str, Any]]:
    """
    Converte experiences do JSON do Apify em uma lista de objetos normalizados:
    {
      "empresa": str,
      "cargo": str,
      "inicio": "YYYY-MM"/"YYYY"/None,
      "fim": "YYYY-MM"/"YYYY"/None,
      "descricao": str|None
    }
    """
    resultado: List[Dict[str, Any]] = []

    for experiencia in perfil.get("experiences", []) or []:
        tem_subcomponentes = bool(experiencia.get("subComponents"))

        if tem_subcomponentes:
            empresa = experiencia.get("title") or experiencia.get("subtitle")
            for bloco_cargo in experiencia.get("subComponents", []) or []:
                cargo = bloco_cargo.get("title")
                legenda = bloco_cargo.get("caption")
                descricao = None
                if bloco_cargo.get("description"):
                    descricao = " ".join([d.get("text", "") for d in bloco_cargo.get("description", [])]).strip() or None
                datas = _extrair_datas_da_legenda(legenda)
                resultado.append({
                    "empresa": empresa,
                    "cargo": cargo,
                    "inicio": datas["inicio"],
                    "fim": datas["fim"],
                    "descricao": descricao
                })
        else:
            # Experiência simples (sem breakdown)
            # Alguns registros usam title como cargo e subtitle como empresa
            cargo = experiencia.get("title")
            empresa = experiencia.get("subtitle") or experiencia.get("title")  # fallback
            legenda = experiencia.get("caption")
            descricao = None
            if experiencia.get("subComponents") and experiencia["subComponents"]:
                # pode vir descrição dentro de subComponents/description em alguns cenários
                descricoes = experiencia["subComponents"][0].get("description", [])
                descricao = " ".join([d.get("text", "") for d in descricoes]).strip() or None
            datas = _extrair_datas_da_legenda(legenda)
            resultado.append({
                "empresa": empresa,
                "cargo": cargo,
                "inicio": datas["inicio"],
                "fim": datas["fim"],
                "descricao": descricao
            })

    # Remove entradas completamente vazias de empresa/cargo
    resultado = [exp for exp in resultado if exp.get("empresa") or exp.get("cargo")]
    return resultado


def _mesclar_experiencias(exp_atual: List[Dict[str, Any]], exp_novas: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Incrementalidade de experiências:
    - Considera um "identificador lógico" = (empresa, cargo, inicio)
    - Se não existir no atual, insere.
    - Mantém as antigas.
    """
    def chave(exp: Dict[str, Any]) -> tuple:
        return (exp.get("empresa") or "", exp.get("cargo") or "", exp.get("inicio") or "")

    existentes = {chave(exp) for exp in (exp_atual or [])}
    para_adicionar = [exp for exp in (exp_novas or []) if chave(exp) not in existentes]
    return (exp_atual or []) + para_adicionar


def _extrair_recomendacoes(perfil: Dict[str, Any]) -> Dict[str, List[str]]:
    """
    Extrai apenas os nomes das recomendações (Received/Given).
    Estrutura alvo:
      {"received": ["Nome A", "Nome B"], "given": ["Nome X"]}
    """
    resultado = {"received": [], "given": []}
    for secao in perfil.get("recommendations", []) or []:
        nome_secao = secao.get("section_name")
        componentes = secao.get("section_components", []) or []
        nomes = [c.get("titleV2") for c in componentes if c.get("titleV2")]
        if nome_secao == "Received":
            resultado["received"].extend(nomes)
        elif nome_secao == "Given":
            resultado["given"].extend(nomes)

    # Deduplica
    resultado["received"] = _remover_duplicados_lista(resultado["received"])
    resultado["given"] = _remover_duplicados_lista(resultado["given"])
    return resultado


def _mesclar_recomendacoes(atual: Optional[Dict[str, List[str]]],
                          novas: Dict[str, List[str]]) -> Dict[str, List[str]]:
    atual = atual or {"received": [], "given": []}
    return {
        "received": _remover_duplicados_lista((atual.get("received") or []) + (novas.get("received") or [])),
        "given": _remover_duplicados_lista((atual.get("given") or []) + (novas.get("given") or []))
    }


def _extrair_certificacoes(perfil: Dict[str, Any]) -> List[str]:
    """
    Extrai títulos de certificações (licensesAndCertificates[].title) como lista de strings.
    """
    resultado = []
    for certificacao in perfil.get("licenseAndCertificates", []) or []:
        titulo = certificacao.get("title")
        if titulo:
            resultado.append(titulo.strip())
    return _remover_duplicados_lista(resultado)


# ---------------------------
# Rota principal
# ---------------------------

@router.post("/contato/{contato_id}", response_model=EnriquecimentoResponse)
def enriquecer_contato(contato_id: int, usuario_atual: dict = Depends(get_current_user)):
    """
    Enriquecer dados de um contato a partir do LinkedIn (via Apify).

    - **contato_id**: ID do contato existente na base.
    - Busca o perfil pela URL do LinkedIn já cadastrada no contato.
    - Atualiza os campos simples:
        - seguidores (followers)
        - conexoes (connections)
        - resumo (headline)
        - url_foto_perfil (profilePicHighQuality)
    - Incrementa (sem sobrescrever):
        - recomendacoes (somente nomes, Received/Given)
        - experiencias (lista JSONB com: empresa, cargo, inicio, fim, descricao)
        - certificacoes (lista de títulos)

    Retorna:
    - ID do contato
    - Campos atualizados
    - Quantidade total de experiências

    Erros:
    - 401: Token JWT inválido
    - 404: Contato não encontrado ou sem LinkedIn cadastrado
    - 500: Erro interno durante o enriquecimento
    """
    if not CHAVE_APIFY:
        raise HTTPException(status_code=500, detail="Chave do Apify ausente em APIFY_LINKEDIN_COMPANY_KEY")

    try:
        # ---------------- DB: obter contato ----------------
        conexao = get_conn()
        cursor = conexao.cursor()

        cursor.execute("""
            SELECT linkedin, experiencias, recomendacoes, certificacoes
              FROM contatos
             WHERE id = %s
        """, (contato_id,))
        contato = cursor.fetchone()

        if not contato:
            conexao.close()
            raise HTTPException(status_code=404, detail="Contato não encontrado")

        if not contato["linkedin"]:
            conexao.close()
            raise HTTPException(status_code=404, detail="Contato sem URL do LinkedIn cadastrada")

        # ---------------- Apify: executar actor ----------------
        cliente = ApifyClient(CHAVE_APIFY)
        entrada_execucao = {"profileUrls": [contato["linkedin"]]}
        execucao = cliente.actor("2SyF0bVxmgGr8IVCZ").call(run_input=entrada_execucao)

        # Dataset → primeiro item
        perfil = None
        for item in cliente.dataset(execucao["defaultDatasetId"]).iterate_items():
            perfil = item
            break

        if not perfil:
            conexao.close()
            raise HTTPException(status_code=500, detail="Nenhum dado retornado pelo Apify")

        # ---------------- Mapear campos simples ----------------
        seguidores = perfil.get("followers")
        conexoes = perfil.get("connections")
        resumo = perfil.get("headline")

        # Pode vir como string direta (exemplo atual do Apify) — manter simples
        url_foto_perfil = perfil.get("profilePicHighQuality")
        if isinstance(url_foto_perfil, dict):
            # fallback se mudar o formato futuramente
            url_foto_perfil = url_foto_perfil.get("url")

        # ---------------- Recomendações (incremental) ----------------
        rec_atual = contato["recomendacoes"] or {"received": [], "given": []}
        rec_novas = _extrair_recomendacoes(perfil)
        rec_final = _mesclar_recomendacoes(rec_atual, rec_novas)

        # ---------------- Experiências (incremental) ----------------
        exp_atual = contato["experiencias"] or []
        exp_novas = _normalizar_experiencias(perfil)
        exp_final = _mesclar_experiencias(exp_atual, exp_novas)

        # ---------------- Certificações (incremental) ----------------
        cert_atual = contato["certificacoes"] or []
        cert_novas = _extrair_certificacoes(perfil)
        cert_final = _remover_duplicados_lista((cert_atual or []) + (cert_novas or []))

        # ---------------- Persistir no banco ----------------
        cursor.execute("""
            UPDATE contatos
               SET seguidores     = %s,
                   conexoes       = %s,
                   resumo         = %s,
                   profile_url    = %s,
                   recomendacoes  = %s,
                   experiencias   = %s,
                   certificacoes  = %s,
                   atualizado_em  = NOW()
             WHERE id = %s
        """, (
            seguidores,
            conexoes,
            resumo,
            url_foto_perfil,
            json.dumps(rec_final, ensure_ascii=False),
            json.dumps(exp_final, ensure_ascii=False),
            json.dumps(cert_final, ensure_ascii=False),
            contato_id
        ))

        conexao.commit()
        conexao.close()

        return EnriquecimentoResponse(
            id=contato_id,
            status="atualizado",
            seguidores=seguidores,
            conexoes=conexoes,
            resumo=resumo,
            url_foto_perfil=url_foto_perfil,
            recomendacoes=RecomendacoesResponse(
                received=rec_final["received"],
                given=rec_final["given"]
            ),
            experiencias_total=len(exp_final),
            certificacoes=cert_final
        )

    except HTTPException:
        # Relevantar HTTPException tal como está
        raise
    except Exception as erro:
        # Falha genérica
        try:
            if 'conexao' in locals():
                conexao.close()
        except Exception:
            pass
        raise HTTPException(status_code=500, detail=f"Erro ao enriquecer contato: {str(erro)}")


# ---------------------------
# Funções auxiliares
# ---------------------------

TOKENS_EXCLUSAO = {
    "diretor", "diretora",
    "gerente",
    "coordenador", "cordenador",
    "supervisor",
    "superintendente",
    "assessor",
    "chefe",
    "lead",
    "manager"
    "Anlista"
    "Chefe"
    "Divisão"
    "Especialista" 
}

def normalizar_texto(txt: str) -> str:
    """
    Remove acentos, coloca em minúsculo e limpa espaços extras.
    """
    txt = unicodedata.normalize("NFKD", txt).encode("ascii", "ignore").decode("utf-8")
    return txt.lower().strip()

def filtrar_tokens_exclusao(cargo_norm: str) -> List[str]:
    """
    Quebra o cargo em tokens e remove palavras de exclusão (níveis hierárquicos).
    """
    tokens = re.split(r"\s+", cargo_norm)
    return [t for t in tokens if t not in TOKENS_EXCLUSAO]

def buscar_departamento_por_cargo(cur, cargo_norm: str) -> Optional[int]:
    """
    Procura no banco se o cargo contém alguma keyword já mapeada.
    Quebra o cargo em tokens isolados, normaliza e compara sem acento.
    """
    cur.execute("""
        SELECT departamento_id
          FROM mapa_cargos_departamentos
         WHERE EXISTS (
            SELECT 1
              FROM jsonb_array_elements_text(cargos) kw
             WHERE EXISTS (
                 SELECT 1
                   FROM unnest(regexp_split_to_array(%s, '\s+')) token
                  WHERE unaccent(lower(token)) = unaccent(lower(kw))
             )
         )
         LIMIT 1
    """, (cargo_norm,))
    row = cur.fetchone()
    return row["departamento_id"] if row else None

# ---------------------------
# Rota principal
# ---------------------------

@router.post("/classificar-departamento/{contato_id}")
def classificar_departamento(contato_id: int, usuario_atual: dict = Depends(get_current_user)):
    try:
        conn = get_conn()
        cur = conn.cursor()

        # Obter contato
        cur.execute("""
            SELECT id, nome, cargo, departamento_id
              FROM contatos
             WHERE id = %s
        """, (contato_id,))
        contato = cur.fetchone()

        if not contato:
            raise HTTPException(status_code=404, detail="Contato não encontrado")

        cargo = contato["cargo"]
        if not cargo or cargo.strip() == "":
            # Se não tem cargo definido → Departamento "Vazio"
            cur.execute("SELECT id FROM departamento WHERE lower(nome) = 'vazio' LIMIT 1")
            dep_id = cur.fetchone()["id"]
            origem = "vazio"
        else:
            cargo_norm = normalizar_texto(cargo)

            # Passo 1: busca offline
            dep_id = buscar_departamento_por_cargo(cur, cargo_norm)
            origem = "offline"

            # Passo 2: fallback IA
            if not dep_id:
                cur.execute("SELECT id, nome FROM departamento")
                departamentos = cur.fetchall()
                nomes_departamentos = [d["nome"] for d in departamentos]

                resposta = client.chat.completions.create(
                    model="gpt-4o-mini",
                    messages=[
                        {"role": "system", "content": "Classifique cargos em departamentos pré-definidos."},
                        {"role": "user", "content": f"Cargo: {cargo}. Departamentos possíveis: {', '.join(nomes_departamentos)}. Retorne apenas o nome do departamento mais adequado."}
                    ],
                    temperature=0
                )
                dep_nome = resposta.choices[0].message.content.strip()

                dep_id = next(
                    (d["id"] for d in departamentos if normalizar_texto(d["nome"]) == normalizar_texto(dep_nome)),
                    None
                )

                if dep_id:
                    origem = "IA"
                    adicionar_cargo_ao_mapa(cur, cargo_norm, dep_id)
                else:
                    # Se não encontrar nada → manda para "Outros"
                    cur.execute("SELECT id FROM departamento WHERE lower(nome) = 'outros' LIMIT 1")
                    dep_id = cur.fetchone()["id"]
                    origem = "outros"

        # Atualizar contato
        cur.execute("""
            UPDATE contatos
               SET departamento_id = %s,
                   atualizado_em = NOW()
             WHERE id = %s
        """, (dep_id, contato_id))
        conn.commit()
        conn.close()

        return {
            "id": contato_id,
            "cargo": cargo,
            "departamento_id": dep_id,
            "status": "classificado",
            "origem": origem
        }

    except HTTPException:
        raise
    except Exception as e:
        if 'conn' in locals():
            conn.close()
        raise HTTPException(status_code=500, detail=f"Erro ao classificar contato: {str(e)}")


# ------------------------------
# Atualizar Hierarquia (reporta_a)
# ------------------------------
@router.post("/api/v1/contatos/atualizar_reporta/{empresa_id}")
def atualizar_reporta(empresa_id: int):
    """
    Recalcula a hierarquia de 'reporta_a' para todos os contatos de uma empresa.
    Regras:
    - C-Level → NULL
    - Diretores → reportam a C-Level
    - Gestores → reportam a Diretores
    - Coordenadores → reportam a Gestores do mesmo departamento, senão ao Diretor
    - Analistas/Especialistas → reportam ao superior imediato (Coordenador → Gerente → Diretor → C-Level)
    - Outro → NULL
    """
    conn = get_db()
    cur = conn.cursor()

    # 1. Buscar contatos da empresa
    cur.execute("""
        SELECT id, nome, nivel_hierarquico_id, departamento_id
        FROM contatos
        WHERE empresa_id = %s
        ORDER BY nivel_hierarquico_id ASC, id ASC
    """, (empresa_id,))
    contatos = cur.fetchall()

    if not contatos:
        raise HTTPException(status_code=404, detail="Nenhum contato encontrado")

    # Função auxiliar
    def encontrar_superior(c):
        nivel = c["nivel_hierarquico_id"]
        depto = c["departamento_id"]

        # Níveis hierárquicos
        C_LEVEL, DIRETOR, GESTOR, COORD, ANALISTA, ESPECIALISTA = 4, 3, 2, 6, 1, 7

        candidatos = [x for x in contatos if x["id"] != c["id"]]

        # C-Level nunca reporta
        if nivel == C_LEVEL:
            return None

        # Diretores reportam a C-Level
        if nivel == DIRETOR:
            sup = [x for x in candidatos if x["nivel_hierarquico_id"] == C_LEVEL]
            return sup[0]["id"] if sup else None

        # Gestores → Diretor
        if nivel == GESTOR:
            sup = [x for x in candidatos if x["nivel_hierarquico_id"] == DIRETOR]
            return sup[0]["id"] if sup else None

        # Coordenadores → Gerente do mesmo departamento, senão Diretor
        if nivel == COORD:
            sup = [x for x in candidatos if x["nivel_hierarquico_id"] == GESTOR and x["departamento_id"] == depto]
            if sup:
                return sup[0]["id"]
            sup = [x for x in candidatos if x["nivel_hierarquico_id"] == DIRETOR]
            return sup[0]["id"] if sup else None

        # Analistas/Especialistas → sobem pela cadeia
        if nivel in [ANALISTA, ESPECIALISTA]:
            for n in [COORD, GESTOR, DIRETOR, C_LEVEL]:
                sup = [x for x in candidatos if x["nivel_hierarquico_id"] == n and (x["departamento_id"] == depto or n in [DIRETOR, C_LEVEL])]
                if sup:
                    return sup[0]["id"]
            return None

        # Outro → sem regra
        return None

    # 2. Atualizar cada contato
    atualizados = []
    for c in contatos:
        novo_superior = encontrar_superior(c)
        cur.execute("UPDATE contatos SET reporta_a = %s WHERE id = %s", (novo_superior, c["id"]))
        atualizados.append({"id": c["id"], "reporta_a": novo_superior})

    conn.commit()
    cur.close()
    conn.close()

    return {
        "status": "ok",
        "empresa_id": empresa_id,
        "contatos_atualizados": atualizados
    }


# ---------------------------
# Validação: Cargo vazio
# ---------------------------
@router.post("/contatos/validar/cargo-vazio/{contato_id}")
def validar_cargo_vazio(contato_id: int, usuario_atual: dict = Depends(get_current_user)):
    """
    Verifica se o contato possui cargo vazio ou nulo.
    Caso esteja vazio, adiciona 'Cargo vazio' às inconsistências do contato.
    """
    conn = get_conn()
    cur = conn.cursor()

    cur.execute("SELECT cargo FROM contatos WHERE id = %s", (contato_id,))
    row = cur.fetchone()

    if not row:
        cur.close()
        conn.close()
        raise HTTPException(status_code=404, detail="Contato não encontrado")

    cargo = row["cargo"] if row else None
    inconsistencias = []

    if not cargo or cargo.strip() == "":
        cur.execute(
            """
            UPDATE contatos
               SET inconsistencias = array_append(inconsistencias, 'Cargo vazio')
             WHERE id = %s
               AND NOT ('Cargo vazio' = ANY(inconsistencias))
            """,
            (contato_id,)
        )
        conn.commit()
        inconsistencias.append("Cargo vazio")

    cur.close()
    conn.close()

    return {
        "status": "ok",
        "contato_id": contato_id,
        "inconsistencias": inconsistencias or ["Nenhuma inconsistência adicionada"]
    }

#======================================================
#linkdin vazio
#=====================================================

@router.post("/contatos/validar/linkedin-vazio/{contato_id}")
def validar_linkedin_vazio(contato_id: int, usuario_atual: dict = Depends(get_current_user)):
    """
    Verifica se o contato possui LinkedIn vazio ou nulo.
    Caso esteja vazio, adiciona 'LinkedIn não cadastrado' às inconsistências do contato.
    """
    conn = get_conn()
    cur = conn.cursor()

    cur.execute("SELECT linkedin, inconsistencias FROM contatos WHERE id = %s", (contato_id,))
    row = cur.fetchone()

    if not row:
        cur.close()
        conn.close()
        raise HTTPException(status_code=404, detail="Contato não encontrado")

    linkedin = row["linkedin"]
    inconsistencias = row["inconsistencias"] or []

    if not linkedin or linkedin.strip() == "":
        if "LinkedIn não cadastrado" not in inconsistencias:
            cur.execute(
                """
                UPDATE contatos
                   SET inconsistencias = array_append(inconsistencias, 'LinkedIn não cadastrado')
                 WHERE id = %s
                """,
                (contato_id,)
            )
            conn.commit()
            inconsistencias.append("LinkedIn não cadastrado")

    cur.close()
    conn.close()

    return {
        "status": "ok",
        "contato_id": contato_id,
        "inconsistencias": inconsistencias or ["Nenhuma inconsistência adicionada"]
    }
