# /atria.ia.br/app/contas.py
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File
from auth import get_current_user
from database import get_conn
from typing import List, Optional
from pydantic import BaseModel, validator
import re
import csv
import io
from datetime import datetime

# Definir router SEM prefixo (será definido no main.py)
router = APIRouter(dependencies=[Depends(get_current_user)])

# ==========================
# 🔹 Modelos Pydantic
# ==========================

class ContaCreate(BaseModel):
    nome: str
    cnpj: str
    setor_id: int
    categoria_id: int
    site: Optional[str] = None
    linkedin: Optional[str] = None
    
    @validator('nome')
    def validar_nome(cls, v):
        if not v or len(v.strip()) < 2:
            raise ValueError('Nome deve ter pelo menos 2 caracteres')
        return v.strip()
    
    @validator('cnpj')
    def validar_cnpj(cls, v):
        # Remove caracteres não numéricos
        cnpj_limpo = re.sub(r'\D', '', v)
        if len(cnpj_limpo) != 14:
            raise ValueError('CNPJ deve ter 14 dígitos')
        return cnpj_limpo
    
    @validator('setor_id')
    def validar_setor_id(cls, v):
        if v <= 0:
            raise ValueError('setor_id deve ser um número positivo')
        return v
    
    @validator('categoria_id')
    def validar_categoria_id(cls, v):
        if v <= 0:
            raise ValueError('categoria_id deve ser um número positivo')
        return v
    
    @validator('site')
    def validar_site(cls, v):
        if v and v.strip():
            site = v.strip()
            # Remove protocolo se presente
            if site.startswith(('http://', 'https://')):
                site = site.replace('http://', '').replace('https://', '')
            return site
        return None
    
    @validator('linkedin')
    def validar_linkedin(cls, v):
        if v and v.strip():
            linkedin = v.strip()
            # Validar se é uma URL válida do LinkedIn
            if not ('linkedin.com' in linkedin or linkedin.startswith('linkedin.com')):
                raise ValueError('LinkedIn deve ser uma URL válida do LinkedIn')
            return linkedin
        return None

class ContaResponse(BaseModel):
    id: int
    nome: str
    cnpj: Optional[str]
    setor_id: Optional[int]
    categoria_id: Optional[int]
    site: Optional[str]
    linkedin: Optional[str]
    razao_social: Optional[str]
    funcionarios: Optional[int]
    estado: Optional[str]
    cidade: Optional[str]
    criado_em: Optional[str]
    atualizado_em: Optional[str]

class ContaUpdate(BaseModel):
    nome: Optional[str] = None
    cnpj: Optional[str] = None
    setor_id: Optional[int] = None
    categoria_id: Optional[int] = None
    site: Optional[str] = None
    linkedin: Optional[str] = None
    
    @validator('cnpj')
    def validar_cnpj(cls, v):
        if v:
            cnpj_limpo = re.sub(r'\D', '', v)
            if len(cnpj_limpo) != 14:
                raise ValueError('CNPJ deve ter 14 dígitos')
            return cnpj_limpo
        return v

# ==========================
# 🔹 Funções Auxiliares
# ==========================

def validar_setor_existe(setor_id: int, cur) -> bool:
    """Verifica se o setor_id existe na tabela setores"""
    cur.execute("SELECT id FROM setores WHERE id = %s", (setor_id,))
    return cur.fetchone() is not None

def validar_categoria_existe(categoria_id: int, cur) -> bool:
    """Verifica se a categoria_id existe na tabela categorias"""
    cur.execute("SELECT id FROM categorias WHERE id = %s", (categoria_id,))
    return cur.fetchone() is not None

def cnpj_ja_existe(cnpj: str, cur, conta_id: int = None) -> bool:
    """Verifica se o CNPJ já existe no banco"""
    if conta_id:
        cur.execute("SELECT id FROM contas WHERE cnpj = %s AND id != %s", (cnpj, conta_id))
    else:
        cur.execute("SELECT id FROM contas WHERE cnpj = %s", (cnpj,))
    return cur.fetchone() is not None

def processar_csv_contas(conteudo_csv: str) -> List[dict]:
    """Processa o conteúdo CSV e retorna lista de contas para criação"""
    contas = []
    csv_reader = csv.DictReader(io.StringIO(conteudo_csv))
    
    # Validar cabeçalhos obrigatórios
    campos_obrigatorios = {'nome', 'cnpj', 'setor_id', 'categoria_id'}
    campos_opcionais = {'site', 'linkedin'}
    campos_validos = campos_obrigatorios | campos_opcionais
    
    if not campos_obrigatorios.issubset(set(csv_reader.fieldnames)):
        raise ValueError(f"CSV deve conter os campos obrigatórios: {', '.join(campos_obrigatorios)}")
    
    for linha_num, linha in enumerate(csv_reader, start=2):  # Start=2 porque linha 1 é cabeçalho
        try:
            # Validar campos obrigatórios
            for campo in campos_obrigatorios:
                if not linha.get(campo, '').strip():
                    raise ValueError(f"Campo '{campo}' é obrigatório na linha {linha_num}")
            
            # Criar objeto conta
            conta_data = {
                'nome': linha['nome'].strip(),
                'cnpj': re.sub(r'\D', '', linha['cnpj']),
                'setor_id': int(linha['setor_id']),
                'categoria_id': int(linha['categoria_id']),
                'site': linha.get('site', '').strip() or None,
                'linkedin': linha.get('linkedin', '').strip() or None
            }
            
            # Validar usando Pydantic
            conta_validada = ContaCreate(**conta_data)
            contas.append(conta_validada.dict())
            
        except (ValueError, TypeError) as e:
            raise ValueError(f"Erro na linha {linha_num}: {str(e)}")
    
    return contas

# ==========================
# 🔹 Rotas CRUD
# ==========================

@router.get("/")
def listar_contas(
    page: int = 1,
    limit: int = 50,
    current_user: dict = Depends(get_current_user)
):
    """
    Lista todas as contas com paginação
    
    - **page**: Número da página (padrão: 1)
    - **limit**: Itens por página (padrão: 50, máximo: 100)
    
    Retorna:
    - Lista paginada de contas com informações completas
    
    Erros:
    - 403: Token JWT inválido
    - 500: Erro interno do servidor
    """
    try:
        # Validar parâmetros
        if page < 1:
            page = 1
        if limit < 1 or limit > 100:
            limit = 50
            
        offset = (page - 1) * limit
        
        conn = get_conn()
        cur = conn.cursor()
        
         # Contar total de contas
        cur.execute("SELECT COUNT(*) as total FROM contas")
        result = cur.fetchone()
        total = result['total'] if result else 0 
         # Buscar contas com paginação
        cur.execute("""
            SELECT c.id, c.nome, c.cnpj, c.setor_id, c.categoria_id, c.site, c.linkedin,
                   c.razao_social, c.funcionarios, c.estado, c.cidade, c.criado_em, c.atualizado_em,
                   s.nome as setor_nome, cat.nome as categoria_nome
            FROM contas c
            LEFT JOIN setores s ON c.setor_id = s.id
            LEFT JOIN categorias cat ON c.categoria_id = cat.id
            ORDER BY c.criado_em DESC
            LIMIT %s OFFSET %s
        """, (limit, offset))
        
        rows = cur.fetchall()
        conn.close()
        
        dados = []
        for r in rows:
            dados.append({
                "id": r["id"],
                "nome": r["nome"],
                "cnpj": r["cnpj"],
                "setor_id": r["setor_id"],
                "setor_nome": r["setor_nome"],
                "categoria_id": r["categoria_id"],
                "categoria_nome": r["categoria_nome"],
                "site": r["site"],
                "linkedin": r["linkedin"],
                "razao_social": r["razao_social"],
                "funcionarios": r["funcionarios"],
                "estado": r["estado"],
                "cidade": r["cidade"],
                "criado_em": r["criado_em"].isoformat() if r["criado_em"] else None,
                "atualizado_em": r["atualizado_em"].isoformat() if r["atualizado_em"] else None
            })
        
        return {
            "total": total,
            "page": page,
            "limit": limit,
            "pages": (total + limit - 1) // limit,
            "dados": dados
        }
    
    except Exception as e:
        print(f"❌ ERRO LISTAR CONTAS: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Erro ao listar contas: {str(e)}")

@router.post("/")
def criar_conta(
    conta: ContaCreate,
    current_user: dict = Depends(get_current_user)
):
    """
    Cria uma nova conta
    
    - **nome**: Nome da empresa (obrigatório)
    - **cnpj**: CNPJ da empresa com 14 dígitos (obrigatório)
    - **setor_id**: ID do setor (obrigatório)
    - **categoria_id**: ID da categoria (obrigatório)
    - **site**: Site da empresa (opcional)
    - **linkedin**: URL do LinkedIn (opcional)
    
    Retorna:
    - ID da conta criada e dados da conta
    
    Erros:
    - 400: Dados inválidos ou CNPJ já existe
    - 403: Token JWT inválido
    - 404: Setor ou categoria não encontrados
    - 500: Erro interno do servidor
    """
    try:
        conn = get_conn()
        cur = conn.cursor()
        
        # Validar se setor existe
        if not validar_setor_existe(conta.setor_id, cur):
            conn.close()
            raise HTTPException(status_code=404, detail=f"Setor com ID {conta.setor_id} não encontrado")
        
        # Validar se categoria existe
        if not validar_categoria_existe(conta.categoria_id, cur):
            conn.close()
            raise HTTPException(status_code=404, detail=f"Categoria com ID {conta.categoria_id} não encontrada")
        
        # Validar se CNPJ já existe
        if cnpj_ja_existe(conta.cnpj, cur):
            conn.close()
            raise HTTPException(status_code=400, detail=f"CNPJ {conta.cnpj} já está cadastrado")
        
        # Inserir nova conta
        cur.execute("""
            INSERT INTO contas (nome, cnpj, setor_id, categoria_id, site, linkedin, criado_por, criado_em, atualizado_em)
            VALUES (%s, %s, %s, %s, %s, %s, %s, NOW(), NOW())
            RETURNING id
        """, (
            conta.nome,
            conta.cnpj,
            conta.setor_id,
            conta.categoria_id,
            conta.site,
            conta.linkedin,
            current_user.get('email', 'sistema')
        ))
        
        novo_id = cur.fetchone()["id"]
        conn.commit()
        
        # Buscar dados completos da conta criada
        cur.execute("""
            SELECT c.*, s.nome as setor_nome, cat.nome as categoria_nome
            FROM contas c
            LEFT JOIN setores s ON c.setor_id = s.id
            LEFT JOIN categorias cat ON c.categoria_id = cat.id
            WHERE c.id = %s
        """, (novo_id,))
        
        conta_criada = cur.fetchone()
        conn.close()
        
        return {
            "id": novo_id,
            "status": "criado",
            "mensagem": "Conta criada com sucesso",
            "dados": {
                "id": conta_criada["id"],
                "nome": conta_criada["nome"],
                "cnpj": conta_criada["cnpj"],
                "setor_id": conta_criada["setor_id"],
                "setor_nome": conta_criada["setor_nome"],
                "categoria_id": conta_criada["categoria_id"],
                "categoria_nome": conta_criada["categoria_nome"],
                "site": conta_criada["site"],
                "linkedin": conta_criada["linkedin"],
                "criado_em": conta_criada["criado_em"].isoformat() if conta_criada["criado_em"] else None
            }
        }
    
    except HTTPException:
        raise
    except Exception as e:
        print(f"❌ ERRO CRIAR CONTA: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Erro ao criar conta: {str(e)}")

@router.post("/lote")
def criar_contas_lote(
    arquivo: UploadFile = File(...),
    current_user: dict = Depends(get_current_user)
):
    """
    Cria múltiplas contas a partir de um arquivo CSV
    
    **Formato do CSV:**
    - Cabeçalho obrigatório: nome,cnpj,setor_id,categoria_id
    - Campos opcionais: site,linkedin
    - Separador: vírgula
    - Codificação: UTF-8
    
    **Exemplo:**
    ```
    nome,cnpj,setor_id,categoria_id,site,linkedin
    Empresa A,12345678000195,1,2,www.empresaa.com,linkedin.com/company/empresaa
    Empresa B,98765432000187,2,1,,linkedin.com/company/empresab
    ```
    
    Retorna:
    - Número de contas criadas e relatório de erros
    
    Erros:
    - 400: Arquivo inválido ou dados incorretos
    - 403: Token JWT inválido
    - 500: Erro interno do servidor
    """
    try:
        # Validar tipo de arquivo
        if not arquivo.filename.endswith('.csv'):
            raise HTTPException(status_code=400, detail="Arquivo deve ser um CSV")
        
        # Ler conteúdo do arquivo
        conteudo = arquivo.file.read().decode('utf-8')
        
        # Processar CSV
        contas_para_criar = processar_csv_contas(conteudo)
        
        if not contas_para_criar:
            raise HTTPException(status_code=400, detail="Nenhuma conta válida encontrada no CSV")
        
        conn = get_conn()
        cur = conn.cursor()
        
        contas_criadas = []
        erros = []
        
        for i, conta_data in enumerate(contas_para_criar, start=1):
            try:
                # Validar se setor existe
                if not validar_setor_existe(conta_data['setor_id'], cur):
                    erros.append(f"Linha {i+1}: Setor ID {conta_data['setor_id']} não encontrado")
                    continue
                
                # Validar se categoria existe
                if not validar_categoria_existe(conta_data['categoria_id'], cur):
                    erros.append(f"Linha {i+1}: Categoria ID {conta_data['categoria_id']} não encontrada")
                    continue
                
                # Validar se CNPJ já existe
                if cnpj_ja_existe(conta_data['cnpj'], cur):
                    erros.append(f"Linha {i+1}: CNPJ {conta_data['cnpj']} já está cadastrado")
                    continue
                
                # Inserir conta
                cur.execute("""
                    INSERT INTO contas (nome, cnpj, setor_id, categoria_id, site, linkedin, criado_por, criado_em, atualizado_em)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, NOW(), NOW())
                    RETURNING id
                """, (
                    conta_data['nome'],
                    conta_data['cnpj'],
                    conta_data['setor_id'],
                    conta_data['categoria_id'],
                    conta_data['site'],
                    conta_data['linkedin'],
                    current_user.get('email', 'sistema')
                ))
                
                novo_id = cur.fetchone()["id"]
                contas_criadas.append({
                    "id": novo_id,
                    "nome": conta_data['nome'],
                    "cnpj": conta_data['cnpj']
                })
                
            except Exception as e:
                erros.append(f"Linha {i+1}: {str(e)}")
        
        conn.commit()
        conn.close()
        
        return {
            "status": "processado",
            "total_processadas": len(contas_para_criar),
            "contas_criadas": len(contas_criadas),
            "erros": len(erros),
            "mensagem": f"{len(contas_criadas)} contas criadas com sucesso",
            "dados_criadas": contas_criadas,
            "detalhes_erros": erros if erros else None
        }
    
    except HTTPException:
        raise
    except Exception as e:
        print(f"❌ ERRO CRIAR CONTAS LOTE: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Erro ao processar lote de contas: {str(e)}")

@router.get("/{conta_id}")
def obter_conta(
    conta_id: int,
    current_user: dict = Depends(get_current_user)
):
    """
    Obtém uma conta específica pelo ID
    
    - **conta_id**: ID da conta
    
    Retorna:
    - Dados completos da conta
    
    Erros:
    - 403: Token JWT inválido
    - 404: Conta não encontrada
    - 500: Erro interno do servidor
    """
    try:
        conn = get_conn()
        cur = conn.cursor()
        
        cur.execute("""
            SELECT c.*, s.nome as setor_nome, cat.nome as categoria_nome
            FROM contas c
            LEFT JOIN setores s ON c.setor_id = s.id
            LEFT JOIN categorias cat ON c.categoria_id = cat.id
            WHERE c.id = %s
        """, (conta_id,))
        
        row = cur.fetchone()
        conn.close()
        
        if not row:
            raise HTTPException(status_code=404, detail="Conta não encontrada")
        
        return {
            "id": row["id"],
            "nome": row["nome"],
            "cnpj": row["cnpj"],
            "setor_id": row["setor_id"],
            "setor_nome": row["setor_nome"],
            "categoria_id": row["categoria_id"],
            "categoria_nome": row["categoria_nome"],
            "site": row["site"],
            "linkedin": row["linkedin"],
            "razao_social": row["razao_social"],
            "funcionarios": row["funcionarios"],
            "estado": row["estado"],
            "cidade": row["cidade"],
            "endereco": row["endereco"],
            "capital_social": float(row["capital_social"]) if row["capital_social"] else None,
            "tipo_estabelecimento": row["tipo_estabelecimento"],
            "inconsistencias": row["inconsistencias"],
            "descricao": row["descricao"],
            "descricao_oficial": row["descricao_oficial"],
            "numero_seguidores": row["numero_seguidores"],
            "logo_url": row["logo_url"],
            "criado_por": row["criado_por"],
            "criado_em": row["criado_em"].isoformat() if row["criado_em"] else None,
            "atualizado_em": row["atualizado_em"].isoformat() if row["atualizado_em"] else None
        }
    
    except HTTPException:
        raise
    except Exception as e:
        print(f"❌ ERRO OBTER CONTA: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Erro ao obter conta: {str(e)}")

@router.put("/{conta_id}")
def atualizar_conta(
    conta_id: int,
    conta: ContaUpdate,
    current_user: dict = Depends(get_current_user)
):
    """
    Atualiza uma conta existente
    
    - **conta_id**: ID da conta a ser atualizada
    - Todos os campos são opcionais
    
    Retorna:
    - Dados atualizados da conta
    
    Erros:
    - 400: Dados inválidos ou CNPJ já existe
    - 403: Token JWT inválido
    - 404: Conta, setor ou categoria não encontrados
    - 500: Erro interno do servidor
    """
    try:
        conn = get_conn()
        cur = conn.cursor()
        
        # Verificar se conta existe
        cur.execute("SELECT id FROM contas WHERE id = %s", (conta_id,))
        if not cur.fetchone():
            conn.close()
            raise HTTPException(status_code=404, detail="Conta não encontrada")
        
        # Preparar campos para atualização
        campos_atualizacao = []
        valores = []
        
        if conta.nome is not None:
            campos_atualizacao.append("nome = %s")
            valores.append(conta.nome)
        
        if conta.cnpj is not None:
            # Validar se CNPJ já existe em outra conta
            if cnpj_ja_existe(conta.cnpj, cur, conta_id):
                conn.close()
                raise HTTPException(status_code=400, detail=f"CNPJ {conta.cnpj} já está cadastrado em outra conta")
            campos_atualizacao.append("cnpj = %s")
            valores.append(conta.cnpj)
        
        if conta.setor_id is not None:
            if not validar_setor_existe(conta.setor_id, cur):
                conn.close()
                raise HTTPException(status_code=404, detail=f"Setor com ID {conta.setor_id} não encontrado")
            campos_atualizacao.append("setor_id = %s")
            valores.append(conta.setor_id)
        
        if conta.categoria_id is not None:
            if not validar_categoria_existe(conta.categoria_id, cur):
                conn.close()
                raise HTTPException(status_code=404, detail=f"Categoria com ID {conta.categoria_id} não encontrada")
            campos_atualizacao.append("categoria_id = %s")
            valores.append(conta.categoria_id)
        
        if conta.site is not None:
            campos_atualizacao.append("site = %s")
            valores.append(conta.site)
        
        if conta.linkedin is not None:
            campos_atualizacao.append("linkedin = %s")
            valores.append(conta.linkedin)
        
        if not campos_atualizacao:
            conn.close()
            raise HTTPException(status_code=400, detail="Nenhum campo fornecido para atualização")
        
        # Adicionar timestamp de atualização
        campos_atualizacao.append("atualizado_em = NOW()")
        valores.append(conta_id)
        
        # Executar atualização
        query = f"UPDATE contas SET {', '.join(campos_atualizacao)} WHERE id = %s"
        cur.execute(query, valores)
        conn.commit()
        
        # Buscar dados atualizados
        cur.execute("""
            SELECT c.*, s.nome as setor_nome, cat.nome as categoria_nome
            FROM contas c
            LEFT JOIN setores s ON c.setor_id = s.id
            LEFT JOIN categorias cat ON c.categoria_id = cat.id
            WHERE c.id = %s
        """, (conta_id,))
        
        conta_atualizada = cur.fetchone()
        conn.close()
        
        return {
            "id": conta_id,
            "status": "atualizado",
            "mensagem": "Conta atualizada com sucesso",
            "dados": {
                "id": conta_atualizada["id"],
                "nome": conta_atualizada["nome"],
                "cnpj": conta_atualizada["cnpj"],
                "setor_id": conta_atualizada["setor_id"],
                "setor_nome": conta_atualizada["setor_nome"],
                "categoria_id": conta_atualizada["categoria_id"],
                "categoria_nome": conta_atualizada["categoria_nome"],
                "site": conta_atualizada["site"],
                "linkedin": conta_atualizada["linkedin"],
                "atualizado_em": conta_atualizada["atualizado_em"].isoformat() if conta_atualizada["atualizado_em"] else None
            }
        }
    
    except HTTPException:
        raise
    except Exception as e:
        print(f"❌ ERRO ATUALIZAR CONTA: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Erro ao atualizar conta: {str(e)}")

@router.delete("/{conta_id}")
def deletar_conta(
    conta_id: int,
    current_user: dict = Depends(get_current_user)
):
    """
    Deleta uma conta
    
    - **conta_id**: ID da conta a ser deletada
    """
    try:
        conn = get_conn()
        cur = conn.cursor()
        
        # ✅ CORREÇÃO: Verificar se conta existe com tratamento correto
        cur.execute("SELECT nome FROM contas WHERE id = %s", (conta_id,))
        result = cur.fetchone()
        
        if not result:
            conn.close()
            raise HTTPException(status_code=404, detail="Conta não encontrada")
        
        # ✅ CORREÇÃO: Acessar o nome corretamente
        nome_conta = result[0]  # Primeiro campo da query

        # Verificar se há contatos vinculados
        cur.execute("SELECT COUNT(*) FROM contatos WHERE empresa_id = %s", (conta_id,))
        count_result = cur.fetchone()
        contatos_count = count_result[0] if count_result else 0
        
        if contatos_count > 0:
            conn.close()
            raise HTTPException(
                status_code=400, 
                detail=f"Não é possível deletar a conta '{nome_conta}'. Existem {contatos_count} contatos vinculados. Delete os contatos primeiro."
            )

        # Deletar conta
        cur.execute("DELETE FROM contas WHERE id = %s", (conta_id,))
        conn.commit()
        conn.close()

        return {
            "id": conta_id,
            "status": "deletado",
            "mensagem": f"Conta '{nome_conta}' deletada com sucesso"
        }
    
    except HTTPException:
        raise
    except Exception as e:
        print(f"❌ ERRO DELETAR CONTA: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Erro ao deletar conta: {str(e)}")
